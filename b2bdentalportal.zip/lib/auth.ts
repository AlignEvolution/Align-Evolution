// Authentication utilities and session management
import { cookies } from "next/headers"

export type UserRole = "dentist" | "admin"

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  clinicName?: string
  cro?: string // Registro profissional do dentista
  createdAt: string
}

export interface Session {
  user: User
  expiresAt: string
}

// Simulated user database
const MOCK_USERS: Record<string, User & { password: string }> = {
  "dentista@exemplo.com": {
    id: "1",
    email: "dentista@exemplo.com",
    password: "dentista123",
    name: "Dr. João Silva",
    role: "dentist",
    clinicName: "Clínica Dental Silva",
    cro: "CRO-SP 12345",
    createdAt: new Date().toISOString(),
  },
  "admin@alignevolution.com": {
    id: "2",
    email: "admin@alignevolution.com",
    password: "admin123",
    name: "Admin Align Evolution",
    role: "admin",
    createdAt: new Date().toISOString(),
  },
}

export async function signIn(email: string, password: string): Promise<User | null> {
  const user = MOCK_USERS[email]
  if (user && user.password === password) {
    const { password: _, ...userWithoutPassword } = user
    await setSession(userWithoutPassword)
    return userWithoutPassword
  }
  return null
}

export async function signUp(
  email: string,
  password: string,
  name: string,
  clinicName?: string,
  cro?: string,
): Promise<User> {
  const newUser: User = {
    id: Math.random().toString(36).substring(7),
    email,
    name,
    role: "dentist",
    clinicName,
    cro,
    createdAt: new Date().toISOString(),
  }

  MOCK_USERS[email] = { ...newUser, password }
  await setSession(newUser)
  return newUser
}

export async function signOut(): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.delete("session")
}

export async function getSession(): Promise<Session | null> {
  const cookieStore = await cookies()
  const sessionCookie = cookieStore.get("session")

  if (!sessionCookie) {
    return null
  }

  try {
    const session: Session = JSON.parse(sessionCookie.value)

    // Check if session is expired
    if (new Date(session.expiresAt) < new Date()) {
      await signOut()
      return null
    }

    return session
  } catch {
    return null
  }
}

async function setSession(user: User): Promise<void> {
  const expiresAt = new Date()
  expiresAt.setDate(expiresAt.getDate() + 7) // 7 days

  const session: Session = {
    user,
    expiresAt: expiresAt.toISOString(),
  }

  const cookieStore = await cookies()
  cookieStore.set("session", JSON.stringify(session), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    expires: expiresAt,
  })
}

export async function requireAuth(allowedRoles?: UserRole[]): Promise<User> {
  const session = await getSession()

  if (!session) {
    throw new Error("Unauthorized")
  }

  if (allowedRoles && !allowedRoles.includes(session.user.role)) {
    throw new Error("Forbidden")
  }

  return session.user
}
