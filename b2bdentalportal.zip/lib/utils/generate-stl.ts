// Helper function to generate valid STL file content in base64
export function generateSTLBase64(): string {
  // Create a simple STL binary file (ASCII STL format converted to binary)
  // This is a minimal valid STL structure
  const stlHeader = new Uint8Array(80) // 80 byte header
  const triangleCount = new Uint32Array([1]) // 1 triangle

  // Create vertices for a simple triangle
  const vertices = new Float32Array([0, 0, 0, 1, 0, 0, 0, 1, 0])

  // Normal vector
  const normal = new Float32Array([0, 0, 1])

  // Combine into one buffer
  const buffer = new ArrayBuffer(80 + 4 + 50 * 1) // header + count + (50 bytes per triangle * 1 triangle)
  const view = new Uint8Array(buffer)

  // Write header (80 bytes)
  for (let i = 0; i < 80; i++) {
    view[i] = 0
  }

  // Write triangle count (4 bytes)
  const countView = new Uint32Array(buffer, 80, 1)
  countView[0] = 1

  // Write triangle data
  const offset = 84
  const triangleData = new Float32Array(buffer, offset)

  // Normal vector (3 floats)
  triangleData[0] = normal[0]
  triangleData[1] = normal[1]
  triangleData[2] = normal[2]

  // Vertex 1 (3 floats)
  triangleData[3] = vertices[0]
  triangleData[4] = vertices[1]
  triangleData[5] = vertices[2]

  // Vertex 2 (3 floats)
  triangleData[6] = vertices[3]
  triangleData[7] = vertices[4]
  triangleData[8] = vertices[5]

  // Vertex 3 (3 floats)
  triangleData[9] = vertices[6]
  triangleData[10] = vertices[7]
  triangleData[11] = vertices[8]

  // Attribute byte count (2 bytes, usually 0)
  const attrView = new Uint16Array(buffer, offset + 48, 1)
  attrView[0] = 0

  // Convert to base64
  let binary = ""
  for (let i = 0; i < view.length; i++) {
    binary += String.fromCharCode(view[i])
  }

  return "data:application/octet-stream;base64," + btoa(binary)
}
