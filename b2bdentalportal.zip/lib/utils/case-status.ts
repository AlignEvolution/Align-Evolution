import type { CaseStatus } from "../types"

export const STATUS_CONFIG: Record<CaseStatus, { label: string; color: string; bgColor: string; icon: string }> = {
  received: {
    label: "Recebido",
    color: "text-blue-700",
    bgColor: "bg-blue-100",
    icon: "inbox",
  },
  pending: {
    label: "Pendência",
    color: "text-orange-700",
    bgColor: "bg-orange-100",
    icon: "alert",
  },
  planning: {
    label: "Em Planejamento",
    color: "text-purple-700",
    bgColor: "bg-purple-100",
    icon: "edit",
  },
  awaiting_approval: {
    label: "Aguardando Aprovação",
    color: "text-yellow-700",
    bgColor: "bg-yellow-100",
    icon: "clock",
  },
  approved: {
    label: "Aprovado",
    color: "text-green-700",
    bgColor: "bg-green-100",
    icon: "check",
  },
  in_production: {
    label: "Em Produção",
    color: "text-indigo-700",
    bgColor: "bg-indigo-100",
    icon: "cog",
  },
  shipped: {
    label: "Enviado",
    color: "text-cyan-700",
    bgColor: "bg-cyan-100",
    icon: "truck",
  },
  delivered: {
    label: "Entregue",
    color: "text-teal-700",
    bgColor: "bg-teal-100",
    icon: "package",
  },
  refinement: {
    label: "Refinamento",
    color: "text-pink-700",
    bgColor: "bg-pink-100",
    icon: "refresh",
  },
  completed: {
    label: "Finalizado",
    color: "text-gray-700",
    bgColor: "bg-gray-100",
    icon: "check-circle",
  },
}

export function getStatusConfig(status: CaseStatus) {
  return STATUS_CONFIG[status]
}
