// Shared types for the application

export type CaseStatus =
  | "received"
  | "pending"
  | "planning"
  | "awaiting_approval"
  | "approved"
  | "in_production"
  | "shipped"
  | "delivered"
  | "refinement"
  | "completed"

export interface Case {
  id: string
  caseNumber: string
  patientName: string
  dentistId: string
  dentistName: string
  status: CaseStatus
  createdAt: string
  updatedAt: string
  dueDate?: string
  priority: "low" | "medium" | "high"
  hasUnreadMessages: boolean
  awaitingDentist: boolean
  awaitingLab: boolean
  planningUrl?: string
  planningVersion?: number
  files: CaseFile[]
  timeline: TimelineEvent[]
  messages: Message[]
  refinements?: Refinement[]
  clinicalPrescription?: ClinicalPrescription
}

export interface CaseFile {
  id: string
  name: string
  type: string
  size: number
  url: string
  uploadedAt: string
  uploadedBy: string
  category: "stl" | "photo" | "pdf" | "radiograph" | "other"
}

export interface TimelineEvent {
  id: string
  type: "status_change" | "file_upload" | "message" | "approval" | "note"
  title: string
  description: string
  timestamp: string
  user: string
  metadata?: Record<string, unknown>
}

export interface Message {
  id: string
  caseId: string
  userId: string
  userName: string
  userRole: "dentist" | "admin"
  content: string
  attachments: CaseFile[]
  timestamp: string
  isRead: boolean
}

export interface Refinement {
  id: string
  caseId: string
  requestedAt: string
  requestedBy: string
  reason: string
  status: "requested" | "planning" | "awaiting_approval" | "approved" | "completed"
  files: CaseFile[]
  planningUrl?: string
  planningVersion?: number
  approvedAt?: string
  completedAt?: string
  timeline: TimelineEvent[]
}

export interface ClinicalPrescription {
  // Arcadas a serem tratadas
  arches: "both" | "upper" | "lower"

  // Tipo de tratamento
  treatmentType: "anterior" | "posterior" | "both"

  // Sobremordida
  overbite: "maintain" | "improve"

  // Linha média
  midline: "maintain" | "improve"

  // Mordida cruzada
  crossbite: "maintain" | "improve"

  // Distalização
  distalization: "yes" | "no"

  // Uso de acessórios - elásticos
  elastics: "yes" | "no"

  // Expansão
  expansion: "yes" | "no"

  // Relação molar
  molarRelationship: {
    left: "maintain" | "improve"
    right: "maintain" | "improve"
  }

  // Relação canina
  canineRelationship: {
    left: "maintain" | "improve"
    right: "maintain" | "improve"
  }

  // IPR - Desgaste interproximal
  ipr: {
    anterior: boolean
    left: boolean
    right: boolean
    none: boolean
  }

  // Restrições de movimentação (dentes marcados)
  restrictedTeeth: number[]

  // Extrações (dentes marcados)
  extractedTeeth: number[]

  // Observações clínicas
  clinicalNotes: string
}

export interface Dentist {
  id: string
  dentistName: string
  clinicName: string
  city: string
  stateUf: string
  neighborhood?: string
  phone: string
  email: string
  status: "active" | "inactive"
  updatedAt: string
  createdAt: string
}
