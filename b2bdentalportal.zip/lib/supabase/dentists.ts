import { createClient } from "./client"
import type { Dentist } from "../types"
import type { Omit } from "lodash"

export async function getDentists() {
  const supabase = createClient()

  const { data, error } = await supabase.from("dentists").select("*").order("created_at", { ascending: false })

  if (error) throw error
  return data as Dentist[]
}

export async function getDentistById(dentistId: string) {
  const supabase = createClient()

  const { data, error } = await supabase.from("dentists").select("*").eq("id", dentistId).single()

  if (error) throw error
  return data as Dentist
}

export async function createDentist(dentist: Omit<Dentist, "id" | "createdAt" | "updatedAt">) {
  const supabase = createClient()

  const { data, error } = await supabase.from("dentists").insert([dentist]).select().single()

  if (error) throw error
  return data as Dentist
}

export async function updateDentist(
  dentistId: string,
  updates: Partial<Omit<Dentist, "id" | "createdAt" | "updatedAt">>,
) {
  const supabase = createClient()

  const { error } = await supabase
    .from("dentists")
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq("id", dentistId)

  if (error) throw error
}

export async function deleteDentist(dentistId: string) {
  const supabase = createClient()

  const { error } = await supabase.from("dentists").delete().eq("id", dentistId)

  if (error) throw error
}
