import { createClient } from "./client"
import type { Case } from "../types"

export async function getCases() {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("cases")
    .select(
      `
      *,
      case_files(*),
      timeline_events(*),
      messages(*),
      clinical_prescriptions(*)
    `,
    )
    .order("created_at", { ascending: false })

  if (error) throw error
  return data as Case[]
}

export async function getCaseById(caseId: string) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("cases")
    .select(
      `
      *,
      case_files(*),
      timeline_events(*),
      messages(*),
      clinical_prescriptions(*)
    `,
    )
    .eq("id", caseId)
    .single()

  if (error) throw error
  return data as Case
}

export async function getCasesByDentist(dentistId: string) {
  const supabase = createClient()

  const { data, error } = await supabase
    .from("cases")
    .select(
      `
      *,
      case_files(*),
      timeline_events(*),
      messages(*)
    `,
    )
    .eq("dentist_id", dentistId)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data as Case[]
}

export async function updateCaseStatus(caseId: string, status: string) {
  const supabase = createClient()

  const { error } = await supabase
    .from("cases")
    .update({
      status,
      updated_at: new Date().toISOString(),
    })
    .eq("id", caseId)

  if (error) throw error
}

export async function uploadCaseFile(caseId: string, file: File, category: string, uploadedBy: string) {
  const supabase = createClient()

  // Upload file to storage
  const fileExtension = file.name.split(".").pop()
  const fileName = `${caseId}/${Date.now()}.${fileExtension}`

  const { data: fileData, error: uploadError } = await supabase.storage.from("case-files").upload(fileName, file)

  if (uploadError) throw uploadError

  // Get public URL
  const { data: urlData } = supabase.storage.from("case-files").getPublicUrl(fileName)

  // Create database record
  const { error: dbError } = await supabase.from("case_files").insert({
    case_id: caseId,
    name: file.name,
    file_type: file.type,
    file_size: file.size,
    file_url: urlData.publicUrl,
    category,
    uploaded_by: uploadedBy,
  })

  if (dbError) throw dbError
}

export async function addTimelineEvent(
  caseId: string,
  eventType: string,
  title: string,
  description: string,
  userName: string,
) {
  const supabase = createClient()

  const { error } = await supabase.from("timeline_events").insert({
    case_id: caseId,
    event_type: eventType,
    title,
    description,
    user_name: userName,
  })

  if (error) throw error
}
