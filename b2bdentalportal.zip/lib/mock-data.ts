// Mock data for development
import type { Case, Dentist } from "./types"

const createSTLBase64 = (name: string) => {
  // This is a minimal valid STL file structure in binary format
  // STL binary format: 80-byte header + 4 bytes for triangle count + triangles
  // We'll create a simple base64 that represents a valid empty STL file
  const headerBytes = new Uint8Array(80)
  const countBytes = new Uint8Array([0, 0, 0, 0]) // 0 triangles

  const combined = new Uint8Array(headerBytes.length + countBytes.length)
  combined.set(headerBytes)
  combined.set(countBytes, headerBytes.length)

  return `data:application/octet-stream;base64,${btoa(String.fromCharCode.apply(null, Array.from(combined)))}`
}

const stlUpperJaw =
  "data:application/octet-stream;base64,AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
const stlLowerJaw =
  "data:application/octet-stream;base64,AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
const jpegImage =
  "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCABkAGQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWm5ybnJ2eoqOkpaanqKmqsrO0tba2uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlbaWmJmaoqOkpaanqKmqsrO0tba2uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigD//Z"

export const MOCK_CASES: Case[] = [
  {
    id: "1",
    caseNumber: "AE-2025-001",
    patientName: "Maria Santos",
    dentistId: "1",
    dentistName: "Dr. João Silva",
    status: "awaiting_approval",
    createdAt: "2025-01-10T10:00:00Z",
    updatedAt: "2025-01-12T15:30:00Z",
    dueDate: "2025-01-20T23:59:59Z",
    priority: "high",
    hasUnreadMessages: true,
    awaitingDentist: true,
    awaitingLab: false,
    planningUrl: "https://viewer.alignevolution.com/case/ae2025001/v1",
    planningVersion: 1,
    clinicalPrescription: {
      arches: "both",
      treatmentType: "both",
      overbite: "improve",
      midline: "improve",
      crossbite: "improve",
      distalization: "yes",
      elastics: "yes",
      expansion: "no",
      molarRelationship: {
        left: "improve",
        right: "maintain",
      },
      canineRelationship: {
        left: "improve",
        right: "improve",
      },
      ipr: {
        anterior: true,
        left: true,
        right: false,
        none: false,
      },
      restrictedTeeth: [18, 28],
      extractedTeeth: [14, 24],
      clinicalNotes: "Paciente com apinhamento severo anterior. Necessário expansão moderada da arcada superior.",
    },
    files: [
      {
        id: "f1",
        name: "upper_arch.stl",
        type: "model/stl",
        size: 2456789,
        url: "data:text/plain;base64,U3RMSBAAAAAAAAAAAAAAAAAAAAA=",
        uploadedAt: "2025-01-10T10:30:00Z",
        uploadedBy: "Dr. João Silva",
        category: "stl",
      },
      {
        id: "f2",
        name: "lower_arch.stl",
        type: "model/stl",
        size: 2398765,
        url: "data:text/plain;base64,U3RMSBAAAAAAAAAAAAAAAAAAAAA=",
        uploadedAt: "2025-01-10T10:30:00Z",
        uploadedBy: "Dr. João Silva",
        category: "stl",
      },
      {
        id: "f3",
        name: "frontal_photo.jpg",
        type: "image/jpeg",
        size: 456789,
        url: "#",
        uploadedAt: "2025-01-10T10:35:00Z",
        uploadedBy: "Dr. João Silva",
        category: "photo",
      },
    ],
    timeline: [
      {
        id: "t1",
        type: "status_change",
        title: "Caso recebido",
        description: "Caso criado e enviado para análise",
        timestamp: "2025-01-10T10:00:00Z",
        user: "Dr. João Silva",
      },
      {
        id: "t2",
        type: "status_change",
        title: "Em planejamento",
        description: "Equipe iniciou o planejamento do caso",
        timestamp: "2025-01-11T09:00:00Z",
        user: "Align Evolution",
      },
      {
        id: "t3",
        type: "status_change",
        title: "Aguardando aprovação",
        description: "Planejamento concluído, aguardando aprovação do dentista",
        timestamp: "2025-01-12T15:30:00Z",
        user: "Align Evolution",
      },
    ],
    messages: [
      {
        id: "m1",
        caseId: "1",
        userId: "2",
        userName: "Align Evolution",
        userRole: "admin",
        content: "Planejamento concluído! Por favor, revise e aprove o setup proposto.",
        attachments: [],
        timestamp: "2025-01-12T15:30:00Z",
        isRead: false,
      },
    ],
  },
  {
    id: "2",
    caseNumber: "AE-2025-002",
    patientName: "Carlos Oliveira",
    dentistId: "1",
    dentistName: "Dr. João Silva",
    status: "in_production",
    createdAt: "2025-01-05T14:20:00Z",
    updatedAt: "2025-01-11T11:00:00Z",
    dueDate: "2025-01-18T23:59:59Z",
    priority: "medium",
    hasUnreadMessages: false,
    awaitingDentist: false,
    awaitingLab: false,
    planningUrl: "https://viewer.alignevolution.com/case/ae2025002/v1",
    planningVersion: 1,
    files: [],
    timeline: [
      {
        id: "t1",
        type: "status_change",
        title: "Caso recebido",
        description: "Caso criado e enviado para análise",
        timestamp: "2025-01-05T14:20:00Z",
        user: "Dr. João Silva",
      },
      {
        id: "t2",
        type: "approval",
        title: "Aprovado",
        description: "Dentista aprovou o planejamento",
        timestamp: "2025-01-08T16:45:00Z",
        user: "Dr. João Silva",
      },
      {
        id: "t3",
        type: "status_change",
        title: "Em produção",
        description: "Alinhadores em processo de fabricação",
        timestamp: "2025-01-11T11:00:00Z",
        user: "Align Evolution",
      },
    ],
    messages: [],
  },
  {
    id: "3",
    caseNumber: "AE-2025-003",
    patientName: "Ana Paula Costa",
    dentistId: "1",
    dentistName: "Dr. João Silva",
    status: "pending",
    createdAt: "2025-01-08T09:15:00Z",
    updatedAt: "2025-01-09T10:20:00Z",
    dueDate: "2025-01-22T23:59:59Z",
    priority: "high",
    hasUnreadMessages: true,
    awaitingDentist: true,
    awaitingLab: false,
    files: [],
    timeline: [
      {
        id: "t1",
        type: "status_change",
        title: "Caso recebido",
        description: "Caso criado",
        timestamp: "2025-01-08T09:15:00Z",
        user: "Dr. João Silva",
      },
      {
        id: "t2",
        type: "status_change",
        title: "Documentação pendente",
        description: "Faltam fotos oclusais e radiografia panorâmica",
        timestamp: "2025-01-09T10:20:00Z",
        user: "Align Evolution",
      },
    ],
    messages: [
      {
        id: "m2",
        caseId: "3",
        userId: "2",
        userName: "Align Evolution",
        userRole: "admin",
        content: "Necessário enviar fotos oclusais (superior e inferior) e radiografia panorâmica para continuar.",
        attachments: [],
        timestamp: "2025-01-09T10:20:00Z",
        isRead: false,
      },
    ],
  },
  {
    id: "4",
    caseNumber: "AE-2024-089",
    patientName: "Roberto Mendes",
    dentistId: "1",
    dentistName: "Dr. João Silva",
    status: "delivered",
    createdAt: "2024-12-15T11:30:00Z",
    updatedAt: "2025-01-08T14:00:00Z",
    priority: "low",
    hasUnreadMessages: false,
    awaitingDentist: false,
    awaitingLab: false,
    files: [],
    timeline: [],
    messages: [],
  },
  {
    id: "5",
    caseNumber: "AE-2025-004",
    patientName: "Juliana Ferreira",
    dentistId: "1",
    dentistName: "Dr. João Silva",
    status: "received",
    createdAt: "2025-01-13T16:45:00Z",
    updatedAt: "2025-01-13T16:45:00Z",
    dueDate: "2025-01-25T23:59:59Z",
    priority: "medium",
    hasUnreadMessages: false,
    awaitingDentist: false,
    awaitingLab: false,
    planningUrl: "https://viewer.alignevolution.com/case/ae2025004/v1",
    planningVersion: 1,
    files: [],
    timeline: [
      {
        id: "t1",
        type: "status_change",
        title: "Caso recebido",
        description: "Caso criado e aguardando análise inicial",
        timestamp: "2025-01-13T16:45:00Z",
        user: "Dr. João Silva",
      },
    ],
    messages: [],
  },
  {
    id: "6",
    caseNumber: "AE-2025-005",
    patientName: "Pamela Norbilato",
    dentistId: "1",
    dentistName: "Dr. João Silva",
    status: "received",
    createdAt: "2025-01-14T08:30:00Z",
    updatedAt: "2025-01-14T08:30:00Z",
    dueDate: "2025-01-28T23:59:59Z",
    priority: "high",
    hasUnreadMessages: false,
    awaitingDentist: false,
    awaitingLab: false,
    planningUrl: "https://viewer.alignevolution.com/case/ae2025005/v1",
    planningVersion: 1,
    files: [
      {
        id: "f1",
        name: "PamelaNorbilato-UpperJawScan.stl",
        type: "application/octet-stream",
        size: 2789456,
        url: stlUpperJaw,
        uploadedAt: "2025-01-14T08:30:00Z",
        uploadedBy: "Dr. João Silva",
        category: "stl",
      },
      {
        id: "f2",
        name: "PamelaNorbilato-LowerJawScan.stl",
        type: "application/octet-stream",
        size: 2654321,
        url: stlLowerJaw,
        uploadedAt: "2025-01-14T08:30:00Z",
        uploadedBy: "Dr. João Silva",
        category: "stl",
      },
      {
        id: "f3",
        name: "frontal_view.jpg",
        type: "image/jpeg",
        size: 512345,
        url: jpegImage,
        uploadedAt: "2025-01-14T08:35:00Z",
        uploadedBy: "Dr. João Silva",
        category: "photo",
      },
    ],
    timeline: [
      {
        id: "t1",
        type: "status_change",
        title: "Caso recebido",
        description: "Caso recebido e pronto para análise inicial",
        timestamp: "2025-01-14T08:30:00Z",
        user: "Dr. João Silva",
      },
    ],
    messages: [],
  },
]

export const MOCK_DENTISTS: Dentist[] = [
  {
    id: "1",
    dentistName: "Dr. João Silva",
    clinicName: "Clínica Dental Silva",
    city: "São Paulo",
    stateUf: "SP",
    neighborhood: "Centro",
    phone: "(11) 99999-9999",
    email: "dentista@exemplo.com",
    status: "active",
    createdAt: "2024-01-15T10:00:00Z",
    updatedAt: "2025-01-14T14:30:00Z",
  },
  {
    id: "2",
    dentistName: "Dra. Maria Santos",
    clinicName: "Clínica Odontológica Santos",
    city: "Rio de Janeiro",
    stateUf: "RJ",
    neighborhood: "Copacabana",
    phone: "(21) 98888-8888",
    email: "maria.santos@clinica.com",
    status: "active",
    createdAt: "2024-02-20T11:30:00Z",
    updatedAt: "2025-01-10T09:15:00Z",
  },
  {
    id: "3",
    dentistName: "Dr. Carlos Oliveira",
    clinicName: "Consultório Oliveira",
    city: "Belo Horizonte",
    stateUf: "MG",
    neighborhood: "Savassi",
    phone: "(31) 97777-7777",
    email: "carlos@consultorio.com",
    status: "inactive",
    createdAt: "2023-11-10T14:00:00Z",
    updatedAt: "2024-12-05T16:45:00Z",
  },
]

export function getCasesByDentist(dentistId: string): Case[] {
  return MOCK_CASES.filter((c) => c.dentistId === dentistId)
}

export function getCaseById(caseId: string): Case | undefined {
  return MOCK_CASES.find((c) => c.id === caseId)
}

export function getDentistById(dentistId: string): Dentist | undefined {
  return MOCK_DENTISTS.find((d) => d.id === dentistId)
}

export function getAllDentists(): Dentist[] {
  return MOCK_DENTISTS
}
