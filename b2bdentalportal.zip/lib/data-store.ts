// Client-side data persistence using localStorage
// This simulates a database for demo purposes
import type { Case } from "./types"
import { MOCK_CASES, MOCK_DENTISTS } from "./mock-data"

const STORAGE_KEY = "align_evolution_cases"
const DENTISTS_STORAGE_KEY = "align_evolution_dentists"

// Initialize storage with mock data if empty
function initializeStorage() {
  if (typeof window === "undefined") return

  const stored = localStorage.getItem(STORAGE_KEY)
  if (!stored) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(MOCK_CASES))
  }
}

// Initialize dentists storage with mock data if empty
function initializeDentistsStorage() {
  if (typeof window === "undefined") return

  const stored = localStorage.getItem(DENTISTS_STORAGE_KEY)
  if (!stored) {
    localStorage.setItem(DENTISTS_STORAGE_KEY, JSON.stringify(MOCK_DENTISTS))
  }
}

// Get all cases from storage
export function getAllCases(): Case[] {
  if (typeof window === "undefined") return MOCK_CASES

  initializeStorage()
  const stored = localStorage.getItem(STORAGE_KEY)
  return stored ? JSON.parse(stored) : MOCK_CASES
}

// Get case by ID
export function getCaseById(caseId: string): Case | undefined {
  const cases = getAllCases()
  return cases.find((c) => c.id === caseId)
}

// Get cases by dentist
export function getCasesByDentist(dentistId: string): Case[] {
  const cases = getAllCases()
  return cases.filter((c) => c.dentistId === dentistId)
}

// Update a case
export function updateCase(caseId: string, updates: Partial<Case>): Case | null {
  if (typeof window === "undefined") return null

  const cases = getAllCases()
  const index = cases.findIndex((c) => c.id === caseId)

  if (index === -1) return null

  const updatedCase = {
    ...cases[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  }

  cases[index] = updatedCase
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cases))

  console.log("[v0] Case updated in storage:", caseId, updates)
  return updatedCase
}

// Update planning URL
export function updatePlanningUrl(caseId: string, planningUrl: string, version?: number): Case | null {
  const caseData = getCaseById(caseId)
  if (!caseData) return null

  const newVersion = version || (caseData.planningVersion || 0) + 1

  return updateCase(caseId, {
    planningUrl,
    planningVersion: newVersion,
  })
}

// Add message to case
export function addMessageToCase(
  caseId: string,
  message: {
    userId: string
    userName: string
    userRole: "dentist" | "admin"
    content: string
    attachments?: Array<{ name: string; url: string; type: string }>
  },
) {
  const caseData = getCaseById(caseId)
  if (!caseData) return null

  const newMessage = {
    id: `m${Date.now()}`,
    caseId,
    ...message,
    timestamp: new Date().toISOString(),
    isRead: false,
  }

  const updatedMessages = [...(caseData.messages || []), newMessage]

  return updateCase(caseId, {
    messages: updatedMessages,
  })
}

// Update case status
export function updateCaseStatus(caseId: string, status: Case["status"], userName: string) {
  const caseData = getCaseById(caseId)
  if (!caseData) return null

  const newTimelineEntry = {
    id: `t${Date.now()}`,
    type: "status_change" as const,
    title: `Status atualizado para ${status}`,
    description: `Status alterado para ${status}`,
    timestamp: new Date().toISOString(),
    user: userName,
  }

  const updatedTimeline = [...(caseData.timeline || []), newTimelineEntry]

  return updateCase(caseId, {
    status,
    timeline: updatedTimeline,
  })
}

export function addRefinementToCase(
  caseId: string,
  refinement: {
    reason: string
    files: Array<{ name: string; url: string; type: string; size: number; category: string }>
    requestedBy: string
  },
): Case | null {
  const caseData = getCaseById(caseId)
  if (!caseData) return null

  const newRefinement = {
    id: `r${Date.now()}`,
    caseId,
    requestedAt: new Date().toISOString(),
    requestedBy: refinement.requestedBy,
    reason: refinement.reason,
    status: "requested" as const,
    files: refinement.files.map((file, index) => ({
      id: `rf${Date.now()}-${index}`,
      name: file.name,
      type: file.type,
      size: file.size,
      url: file.url,
      uploadedAt: new Date().toISOString(),
      uploadedBy: refinement.requestedBy,
      category: file.category as any,
    })),
    timeline: [
      {
        id: `t${Date.now()}`,
        type: "note" as const,
        title: "Refinamento solicitado",
        description: refinement.reason,
        timestamp: new Date().toISOString(),
        user: refinement.requestedBy,
      },
    ],
  }

  const updatedRefinements = [...(caseData.refinements || []), newRefinement]

  // Add to case timeline
  const newTimelineEntry = {
    id: `t${Date.now()}`,
    type: "note" as const,
    title: "Refinamento solicitado",
    description: `Dentista solicitou refinamento: ${refinement.reason}`,
    timestamp: new Date().toISOString(),
    user: refinement.requestedBy,
  }

  return updateCase(caseId, {
    status: "refinement",
    refinements: updatedRefinements,
    timeline: [...(caseData.timeline || []), newTimelineEntry],
  })
}

export function updateRefinementPlanningUrl(caseId: string, refinementId: string, planningUrl: string): Case | null {
  const caseData = getCaseById(caseId)
  if (!caseData || !caseData.refinements) return null

  const refinements = caseData.refinements.map((ref) => {
    if (ref.id === refinementId) {
      const newVersion = (ref.planningVersion || 0) + 1
      return {
        ...ref,
        planningUrl,
        planningVersion: newVersion,
        status: "awaiting_approval" as const,
        timeline: [
          ...ref.timeline,
          {
            id: `t${Date.now()}`,
            type: "note" as const,
            title: "Planejamento disponível",
            description: `Versão ${newVersion} do planejamento disponível para aprovação`,
            timestamp: new Date().toISOString(),
            user: "Admin",
          },
        ],
      }
    }
    return ref
  })

  return updateCase(caseId, { refinements })
}

export function approveRefinement(caseId: string, refinementId: string, userName: string): Case | null {
  const caseData = getCaseById(caseId)
  if (!caseData || !caseData.refinements) return null

  const refinements = caseData.refinements.map((ref) => {
    if (ref.id === refinementId) {
      return {
        ...ref,
        status: "approved" as const,
        approvedAt: new Date().toISOString(),
        timeline: [
          ...ref.timeline,
          {
            id: `t${Date.now()}`,
            type: "approval" as const,
            title: "Refinamento aprovado",
            description: "Dentista aprovou o planejamento do refinamento",
            timestamp: new Date().toISOString(),
            user: userName,
          },
        ],
      }
    }
    return ref
  })

  return updateCase(caseId, { refinements })
}

export function completeRefinement(caseId: string, refinementId: string): Case | null {
  const caseData = getCaseById(caseId)
  if (!caseData || !caseData.refinements) return null

  const refinements = caseData.refinements.map((ref) => {
    if (ref.id === refinementId) {
      return {
        ...ref,
        status: "completed" as const,
        completedAt: new Date().toISOString(),
        timeline: [
          ...ref.timeline,
          {
            id: `t${Date.now()}`,
            type: "status_change" as const,
            title: "Refinamento concluído",
            description: "Refinamento foi finalizado",
            timestamp: new Date().toISOString(),
            user: "Admin",
          },
        ],
      }
    }
    return ref
  })

  return updateCase(caseId, { refinements })
}

export function createCase(caseData: Partial<Case> & { patientName: string; dentistId: string }): Case {
  if (typeof window === "undefined") {
    throw new Error("Cannot create case on server")
  }

  const cases = getAllCases()

  const newCase: Case = {
    id: `${Date.now()}`,
    caseNumber: `CASE-${String(cases.length + 1).padStart(4, "0")}`,
    patientName: caseData.patientName,
    patientAge: caseData.patientAge || "",
    dentistId: caseData.dentistId,
    dentistName: caseData.dentistName || "Dentista",
    status: "received",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
    files: caseData.files || [],
    messages: [],
    timeline: [
      {
        id: `t${Date.now()}`,
        type: "status_change",
        title: "Caso criado",
        description: "Novo caso recebido para planejamento",
        timestamp: new Date().toISOString(),
        user: caseData.dentistName || "Dentista",
      },
    ],
    notes: caseData.notes || "",
    clinicalPrescription: caseData.clinicalPrescription,
    refinements: [],
  }

  cases.push(newCase)
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cases))

  console.log("[v0] New case created and saved:", newCase.id, newCase.caseNumber)
  return newCase
}

// Dentist management functions

// Get all dentists from storage
export function getAllDentists(): any[] {
  if (typeof window === "undefined") return []

  initializeDentistsStorage()
  const stored = localStorage.getItem(DENTISTS_STORAGE_KEY)
  return stored ? JSON.parse(stored) : []
}

// Get dentist by ID
export function getDentistById(dentistId: string): any {
  const dentists = getAllDentists()
  return dentists.find((d: any) => d.id === dentistId)
}

// Update a dentist
export function updateDentist(dentistId: string, updates: Record<string, any>): any {
  if (typeof window === "undefined") return null

  const dentists = getAllDentists()
  const index = dentists.findIndex((d: any) => d.id === dentistId)

  if (index === -1) return null

  const updatedDentist = {
    ...dentists[index],
    ...updates,
    updatedAt: new Date().toISOString(),
  }

  dentists[index] = updatedDentist
  localStorage.setItem(DENTISTS_STORAGE_KEY, JSON.stringify(dentists))

  console.log("[v0] Dentist updated in storage:", dentistId)
  return updatedDentist
}
