import type { Case } from "@/lib/types"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getStatusConfig } from "@/lib/utils/case-status"
import Link from "next/link"

interface CasesListProps {
  cases: Case[]
}

export function CasesList({ cases }: CasesListProps) {
  if (cases.length === 0) {
    return (
      <Card className="border-none shadow-sm">
        <CardContent className="p-12 text-center">
          <div className="flex flex-col items-center gap-4">
            <div className="h-16 w-16 bg-slate-100 rounded-full flex items-center justify-center">
              <svg className="h-8 w-8 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-1">Nenhum caso encontrado</h3>
              <p className="text-slate-600">Comece criando seu primeiro caso ortodôntico</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {cases.map((caseItem) => {
        const statusConfig = getStatusConfig(caseItem.status)
        const daysRemaining = caseItem.dueDate
          ? Math.ceil((new Date(caseItem.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
          : null

        return (
          <Link key={caseItem.id} href={`/dashboard/casos/${caseItem.id}`}>
            <Card className="border-none shadow-sm hover:shadow-md transition-all hover:scale-[1.01] cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-slate-900">{caseItem.patientName}</h3>
                      <Badge variant="secondary" className="text-xs">
                        {caseItem.caseNumber}
                      </Badge>
                      {caseItem.hasUnreadMessages && (
                        <Badge className="bg-green-600 hover:bg-green-700 text-xs">
                          <svg className="h-3 w-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                            <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                          </svg>
                          Nova mensagem
                        </Badge>
                      )}
                      {caseItem.awaitingDentist && (
                        <Badge className="bg-orange-600 hover:bg-orange-700 text-xs">Requer atenção</Badge>
                      )}
                    </div>

                    <div className="flex items-center gap-4 text-sm text-slate-600 mb-3">
                      <div className="flex items-center gap-1">
                        <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                          />
                        </svg>
                        {new Date(caseItem.createdAt).toLocaleDateString("pt-BR")}
                      </div>

                      {daysRemaining !== null && (
                        <div className="flex items-center gap-1">
                          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                            />
                          </svg>
                          {daysRemaining > 0 ? `${daysRemaining} dias restantes` : "Prazo vencido"}
                        </div>
                      )}

                      {caseItem.files.length > 0 && (
                        <div className="flex items-center gap-1">
                          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"
                            />
                          </svg>
                          {caseItem.files.length} arquivo{caseItem.files.length !== 1 ? "s" : ""}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <Badge className={`${statusConfig.bgColor} ${statusConfig.color} hover:${statusConfig.bgColor}`}>
                      {statusConfig.label}
                    </Badge>
                    {caseItem.priority === "high" && (
                      <Badge variant="destructive" className="text-xs">
                        Alta prioridade
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        )
      })}
    </div>
  )
}
