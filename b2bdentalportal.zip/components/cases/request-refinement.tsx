"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Upload, X } from "lucide-react"
import { addRefinementToCase } from "@/lib/data-store"

interface RequestRefinementProps {
  caseId: string
  dentistName: string
  onSuccess?: () => void
}

interface FileWithPreview {
  file: File
  preview?: string
  category: "stl" | "photo"
}

export function RequestRefinement({ caseId, dentistName, onSuccess }: RequestRefinementProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [reason, setReason] = useState("")
  const [files, setFiles] = useState<FileWithPreview[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, category: "stl" | "photo") => {
    const selectedFiles = Array.from(e.target.files || [])

    const newFiles = selectedFiles.map((file) => ({
      file,
      category,
      preview: file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined,
    }))

    setFiles((prev) => [...prev, ...newFiles])
  }

  const removeFile = (index: number) => {
    setFiles((prev) => {
      const newFiles = [...prev]
      if (newFiles[index].preview) {
        URL.revokeObjectURL(newFiles[index].preview!)
      }
      newFiles.splice(index, 1)
      return newFiles
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!reason.trim() || files.length === 0) return

    setIsSubmitting(true)

    try {
      // In a real app, upload files to storage first
      // For demo, we'll use mock URLs
      const uploadedFiles = files.map((f) => ({
        name: f.file.name,
        url: URL.createObjectURL(f.file),
        type: f.file.type,
        size: f.file.size,
        category: f.category,
      }))

      const result = addRefinementToCase(caseId, {
        reason,
        files: uploadedFiles,
        requestedBy: dentistName,
      })

      if (result) {
        setReason("")
        setFiles([])
        setIsOpen(false)
        onSuccess?.()
        window.location.reload()
      }
    } catch (error) {
      console.error("Error requesting refinement:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!isOpen) {
    return (
      <Button onClick={() => setIsOpen(true)} className="bg-gradient-to-r from-purple-600 to-indigo-600">
        Solicitar Refinamento
      </Button>
    )
  }

  const stlFiles = files.filter((f) => f.category === "stl")
  const photoFiles = files.filter((f) => f.category === "photo")

  return (
    <Card className="p-6 border-purple-200 bg-gradient-to-br from-purple-50 to-indigo-50">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-slate-900">Solicitar Refinamento</h3>
        <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Motivo do Refinamento *</label>
          <Textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Descreva o que precisa ser ajustado no tratamento..."
            className="min-h-24"
            required
          />
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Arquivos STL * ({stlFiles.length})</label>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center">
              <input
                type="file"
                accept=".stl"
                multiple
                onChange={(e) => handleFileChange(e, "stl")}
                className="hidden"
                id="stl-refinement"
              />
              <label htmlFor="stl-refinement" className="cursor-pointer">
                <Upload className="h-8 w-8 mx-auto text-slate-400 mb-2" />
                <p className="text-sm text-slate-600">Upload arquivos STL</p>
              </label>
            </div>
            {stlFiles.map((f, i) => (
              <div key={i} className="flex items-center justify-between mt-2 p-2 bg-white rounded border">
                <span className="text-sm truncate">{f.file.name}</span>
                <Button type="button" variant="ghost" size="sm" onClick={() => removeFile(files.indexOf(f))}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Fotos Intraorais * ({photoFiles.length})
            </label>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center">
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={(e) => handleFileChange(e, "photo")}
                className="hidden"
                id="photos-refinement"
              />
              <label htmlFor="photos-refinement" className="cursor-pointer">
                <Upload className="h-8 w-8 mx-auto text-slate-400 mb-2" />
                <p className="text-sm text-slate-600">Upload fotos</p>
              </label>
            </div>
            {photoFiles.map((f, i) => (
              <div key={i} className="flex items-center justify-between mt-2 p-2 bg-white rounded border">
                <span className="text-sm truncate">{f.file.name}</span>
                <Button type="button" variant="ghost" size="sm" onClick={() => removeFile(files.indexOf(f))}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-3 justify-end">
          <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
            Cancelar
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting || !reason.trim() || files.length === 0}
            className="bg-gradient-to-r from-purple-600 to-indigo-600"
          >
            {isSubmitting ? "Enviando..." : "Solicitar Refinamento"}
          </Button>
        </div>
      </form>
    </Card>
  )
}
