"use client"
import { cn } from "@/lib/utils"

interface OdontogramProps {
  selectedTeeth: number[]
  onTeethChange: (teeth: number[]) => void
  mode: "restriction" | "extraction"
  disabled?: boolean
}

export function Odontogram({ selectedTeeth, onTeethChange, mode, disabled }: OdontogramProps) {
  const toggleTooth = (toothNumber: number) => {
    if (disabled) return

    if (selectedTeeth.includes(toothNumber)) {
      onTeethChange(selectedTeeth.filter((t) => t !== toothNumber))
    } else {
      onTeethChange([...selectedTeeth, toothNumber])
    }
  }

  // Numeração FDI - Arcada superior: 18-11, 21-28 | Arcada inferior: 48-41, 31-38
  const upperRight = [18, 17, 16, 15, 14, 13, 12, 11]
  const upperLeft = [21, 22, 23, 24, 25, 26, 27, 28]
  const lowerLeft = [31, 32, 33, 34, 35, 36, 37, 38]
  const lowerRight = [48, 47, 46, 45, 44, 43, 42, 41]

  const Tooth = ({ number }: { number: number }) => {
    const isSelected = selectedTeeth.includes(number)
    const isRestriction = mode === "restriction"

    return (
      <button
        type="button"
        onClick={() => toggleTooth(number)}
        disabled={disabled}
        className={cn(
          "relative w-10 h-14 border-2 rounded-md transition-all hover:scale-105 disabled:cursor-not-allowed",
          isSelected
            ? isRestriction
              ? "bg-green-100 border-green-500"
              : "bg-red-100 border-red-500"
            : "bg-white border-slate-300 hover:border-slate-400",
        )}
      >
        <span className="absolute top-1 left-1/2 -translate-x-1/2 text-[10px] font-medium text-slate-600">
          {number}
        </span>
        {isSelected && (
          <div className="absolute inset-0 flex items-center justify-center">
            {isRestriction ? (
              <div className="w-6 h-6 rounded-full border-3 border-green-600" />
            ) : (
              <svg className="w-8 h-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
              </svg>
            )}
          </div>
        )}
      </button>
    )
  }

  return (
    <div className="space-y-6">
      {/* Arcada Superior */}
      <div className="space-y-2">
        <div className="text-sm font-medium text-slate-700 text-center">Arcada Superior</div>
        <div className="flex justify-center gap-8">
          <div className="flex gap-1">
            {upperRight.map((tooth) => (
              <Tooth key={tooth} number={tooth} />
            ))}
          </div>
          <div className="w-px bg-slate-300" />
          <div className="flex gap-1">
            {upperLeft.map((tooth) => (
              <Tooth key={tooth} number={tooth} />
            ))}
          </div>
        </div>
      </div>

      {/* Divisor */}
      <div className="h-px bg-slate-300" />

      {/* Arcada Inferior */}
      <div className="space-y-2">
        <div className="text-sm font-medium text-slate-700 text-center">Arcada Inferior</div>
        <div className="flex justify-center gap-8">
          <div className="flex gap-1">
            {lowerRight.map((tooth) => (
              <Tooth key={tooth} number={tooth} />
            ))}
          </div>
          <div className="w-px bg-slate-300" />
          <div className="flex gap-1">
            {lowerLeft.map((tooth) => (
              <Tooth key={tooth} number={tooth} />
            ))}
          </div>
        </div>
      </div>

      {/* Legenda */}
      <div className="flex items-center justify-center gap-6 pt-4 text-sm">
        {mode === "restriction" ? (
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full border-2 border-green-600" />
            <span className="text-slate-600">Restrição de movimentação</span>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <svg className="w-4 h-4 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
            </svg>
            <span className="text-slate-600">Extração</span>
          </div>
        )}
      </div>
    </div>
  )
}
