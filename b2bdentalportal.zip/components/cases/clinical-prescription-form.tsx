"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Odontogram } from "./odontogram"
import type { ClinicalPrescription } from "@/lib/types"

interface ClinicalPrescriptionFormProps {
  onComplete: (prescription: ClinicalPrescription) => void
  onBack: () => void
  disabled?: boolean
}

export function ClinicalPrescriptionForm({ onComplete, onBack, disabled }: ClinicalPrescriptionFormProps) {
  const [prescription, setPrescription] = useState<ClinicalPrescription>({
    arches: "both",
    treatmentType: "both",
    overbite: "maintain",
    midline: "maintain",
    crossbite: "maintain",
    distalization: "no",
    elastics: "no",
    expansion: "no",
    molarRelationship: { left: "maintain", right: "maintain" },
    canineRelationship: { left: "maintain", right: "maintain" },
    ipr: { anterior: false, left: false, right: false, none: true },
    restrictedTeeth: [],
    extractedTeeth: [],
    clinicalNotes: "",
  })

  const handleSubmit = () => {
    onComplete(prescription)
  }

  const RadioGroup = ({
    label,
    options,
    value,
    onChange,
  }: {
    label: string
    options: { value: string; label: string }[]
    value: string
    onChange: (value: string) => void
  }) => (
    <div className="space-y-2">
      <Label className="text-sm font-semibold text-slate-900">{label}</Label>
      <div className="flex flex-wrap gap-3">
        {options.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            disabled={disabled}
            className={`px-4 py-2 rounded-lg border-2 transition-all ${
              value === option.value
                ? "bg-blue-50 border-blue-500 text-blue-700 font-medium"
                : "bg-white border-slate-300 text-slate-700 hover:border-slate-400"
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  )

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle>Prescrição Clínica para Alinhadores</CardTitle>
          <CardDescription>
            Preencha todas as decisões clínicas para o planejamento digital do tratamento com alinhadores
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Arcadas */}
          <RadioGroup
            label="1. Arcadas a serem tratadas *"
            options={[
              { value: "both", label: "Ambas as arcadas" },
              { value: "upper", label: "Somente superior" },
              { value: "lower", label: "Somente inferior" },
            ]}
            value={prescription.arches}
            onChange={(value) => setPrescription({ ...prescription, arches: value as any })}
          />

          {/* Tipo de tratamento */}
          <RadioGroup
            label="2. Tipo de tratamento *"
            options={[
              { value: "anterior", label: "Anterior" },
              { value: "posterior", label: "Posterior" },
              { value: "both", label: "Anterior e posterior" },
            ]}
            value={prescription.treatmentType}
            onChange={(value) => setPrescription({ ...prescription, treatmentType: value as any })}
          />

          {/* Sobremordida */}
          <RadioGroup
            label="3. Sobremordida *"
            options={[
              { value: "maintain", label: "Manter" },
              { value: "improve", label: "Melhorar" },
            ]}
            value={prescription.overbite}
            onChange={(value) => setPrescription({ ...prescription, overbite: value as any })}
          />

          {/* Linha média */}
          <RadioGroup
            label="4. Linha média *"
            options={[
              { value: "maintain", label: "Manter" },
              { value: "improve", label: "Melhorar" },
            ]}
            value={prescription.midline}
            onChange={(value) => setPrescription({ ...prescription, midline: value as any })}
          />

          {/* Mordida cruzada */}
          <RadioGroup
            label="5. Mordida cruzada *"
            options={[
              { value: "maintain", label: "Manter" },
              { value: "improve", label: "Melhorar" },
            ]}
            value={prescription.crossbite}
            onChange={(value) => setPrescription({ ...prescription, crossbite: value as any })}
          />

          {/* Distalização */}
          <RadioGroup
            label="6. Distalização *"
            options={[
              { value: "yes", label: "Realizar" },
              { value: "no", label: "Não realizar" },
            ]}
            value={prescription.distalization}
            onChange={(value) => setPrescription({ ...prescription, distalization: value as any })}
          />

          {/* Elásticos */}
          <RadioGroup
            label="7. Uso de acessórios - elásticos *"
            options={[
              { value: "yes", label: "Sim" },
              { value: "no", label: "Não" },
            ]}
            value={prescription.elastics}
            onChange={(value) => setPrescription({ ...prescription, elastics: value as any })}
          />

          {/* Expansão */}
          <RadioGroup
            label="8. Expansão *"
            options={[
              { value: "yes", label: "Realizar" },
              { value: "no", label: "Não realizar" },
            ]}
            value={prescription.expansion}
            onChange={(value) => setPrescription({ ...prescription, expansion: value as any })}
          />
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle>Relações Oclusais</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Relação Molar */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold text-slate-900">9. Relação molar *</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm text-slate-700">Lado esquerdo</Label>
                <div className="flex gap-2">
                  {["maintain", "improve"].map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() =>
                        setPrescription({
                          ...prescription,
                          molarRelationship: { ...prescription.molarRelationship, left: value as any },
                        })
                      }
                      disabled={disabled}
                      className={`flex-1 px-4 py-2 rounded-lg border-2 transition-all ${
                        prescription.molarRelationship.left === value
                          ? "bg-blue-50 border-blue-500 text-blue-700 font-medium"
                          : "bg-white border-slate-300 text-slate-700 hover:border-slate-400"
                      }`}
                    >
                      {value === "maintain" ? "Manter" : "Melhorar"}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-slate-700">Lado direito</Label>
                <div className="flex gap-2">
                  {["maintain", "improve"].map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() =>
                        setPrescription({
                          ...prescription,
                          molarRelationship: { ...prescription.molarRelationship, right: value as any },
                        })
                      }
                      disabled={disabled}
                      className={`flex-1 px-4 py-2 rounded-lg border-2 transition-all ${
                        prescription.molarRelationship.right === value
                          ? "bg-blue-50 border-blue-500 text-blue-700 font-medium"
                          : "bg-white border-slate-300 text-slate-700 hover:border-slate-400"
                      }`}
                    >
                      {value === "maintain" ? "Manter" : "Melhorar"}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Relação Canina */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold text-slate-900">10. Relação canina *</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm text-slate-700">Lado esquerdo</Label>
                <div className="flex gap-2">
                  {["maintain", "improve"].map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() =>
                        setPrescription({
                          ...prescription,
                          canineRelationship: { ...prescription.canineRelationship, left: value as any },
                        })
                      }
                      disabled={disabled}
                      className={`flex-1 px-4 py-2 rounded-lg border-2 transition-all ${
                        prescription.canineRelationship.left === value
                          ? "bg-blue-50 border-blue-500 text-blue-700 font-medium"
                          : "bg-white border-slate-300 text-slate-700 hover:border-slate-400"
                      }`}
                    >
                      {value === "maintain" ? "Manter" : "Melhorar"}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-slate-700">Lado direito</Label>
                <div className="flex gap-2">
                  {["maintain", "improve"].map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() =>
                        setPrescription({
                          ...prescription,
                          canineRelationship: { ...prescription.canineRelationship, right: value as any },
                        })
                      }
                      disabled={disabled}
                      className={`flex-1 px-4 py-2 rounded-lg border-2 transition-all ${
                        prescription.canineRelationship.right === value
                          ? "bg-blue-50 border-blue-500 text-blue-700 font-medium"
                          : "bg-white border-slate-300 text-slate-700 hover:border-slate-400"
                      }`}
                    >
                      {value === "maintain" ? "Manter" : "Melhorar"}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* IPR */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold text-slate-900">11. IPR - Desgaste interproximal *</Label>
            <div className="space-y-2">
              {[
                { key: "anterior", label: "Realizar IPR anterior" },
                { key: "left", label: "Realizar IPR lado esquerdo" },
                { key: "right", label: "Realizar IPR lado direito" },
                { key: "none", label: "Não realizar IPR" },
              ].map((option) => (
                <div key={option.key} className="flex items-center space-x-2">
                  <Checkbox
                    id={`ipr-${option.key}`}
                    checked={prescription.ipr[option.key as keyof typeof prescription.ipr]}
                    onCheckedChange={(checked) => {
                      const newIpr = { ...prescription.ipr, [option.key]: checked }
                      if (option.key === "none" && checked) {
                        newIpr.anterior = false
                        newIpr.left = false
                        newIpr.right = false
                      } else if (option.key !== "none" && checked) {
                        newIpr.none = false
                      }
                      setPrescription({ ...prescription, ipr: newIpr })
                    }}
                    disabled={disabled}
                  />
                  <Label htmlFor={`ipr-${option.key}`} className="cursor-pointer text-slate-700">
                    {option.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle>12. Restrições de Movimentação Dentária</CardTitle>
          <CardDescription>Selecione os dentes que NÃO devem sofrer movimentação no planejamento</CardDescription>
        </CardHeader>
        <CardContent>
          <Odontogram
            selectedTeeth={prescription.restrictedTeeth}
            onTeethChange={(teeth) => setPrescription({ ...prescription, restrictedTeeth: teeth })}
            mode="restriction"
            disabled={disabled}
          />
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle>13. Extrações</CardTitle>
          <CardDescription>Selecione os dentes que devem ser considerados extraídos no setup</CardDescription>
        </CardHeader>
        <CardContent>
          <Odontogram
            selectedTeeth={prescription.extractedTeeth}
            onTeethChange={(teeth) => setPrescription({ ...prescription, extractedTeeth: teeth })}
            mode="extraction"
            disabled={disabled}
          />
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle>14. Observações Clínicas</CardTitle>
          <CardDescription>Descrição complementar do caso e informações adicionais relevantes</CardDescription>
        </CardHeader>
        <CardContent>
          <textarea
            value={prescription.clinicalNotes}
            onChange={(e) => setPrescription({ ...prescription, clinicalNotes: e.target.value })}
            placeholder="Descreva particularidades do caso, objetivos específicos, informações sobre o paciente, etc."
            rows={6}
            disabled={disabled}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
          />
        </CardContent>
      </Card>

      <div className="flex items-center justify-between pt-6 border-t border-slate-200">
        <Button type="button" variant="outline" onClick={onBack} disabled={disabled}>
          Voltar
        </Button>

        <Button type="button" onClick={handleSubmit} disabled={disabled} className="min-w-[200px]">
          Continuar para Upload de Arquivos
        </Button>
      </div>
    </div>
  )
}
