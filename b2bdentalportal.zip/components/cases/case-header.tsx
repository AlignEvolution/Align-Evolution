import type { Case } from "@/lib/types"
import type { UserRole } from "@/lib/auth"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getStatusConfig } from "@/lib/utils/case-status"
import Link from "next/link"

interface CaseHeaderProps {
  caseData: Case
  userRole: UserRole
}

export function CaseHeader({ caseData, userRole }: CaseHeaderProps) {
  const statusConfig = getStatusConfig(caseData.status)
  const daysRemaining = caseData.dueDate
    ? Math.ceil((new Date(caseData.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    : null

  return (
    <Card className="border-none shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Link href={userRole === "admin" ? "/admin" : "/dashboard"}>
                <Button variant="ghost" size="sm">
                  <svg className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                  Voltar
                </Button>
              </Link>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-2">{caseData.patientName}</h1>

            <div className="flex flex-wrap items-center gap-3 mb-4">
              <Badge variant="secondary" className="text-sm">
                {caseData.caseNumber}
              </Badge>
              <Badge className={`${statusConfig.bgColor} ${statusConfig.color} hover:${statusConfig.bgColor}`}>
                {statusConfig.label}
              </Badge>

              {caseData.priority === "high" && (
                <Badge variant="destructive" className="text-sm">
                  Alta Prioridade
                </Badge>
              )}

              {caseData.awaitingDentist && (
                <Badge className="bg-orange-600 hover:bg-orange-700">Requer sua atenção</Badge>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-4 text-sm text-slate-600">
              <div className="flex items-center gap-2">
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                  />
                </svg>
                <span>{caseData.dentistName}</span>
              </div>

              <div className="flex items-center gap-2">
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
                <span>Criado em {new Date(caseData.createdAt).toLocaleDateString("pt-BR")}</span>
              </div>

              {daysRemaining !== null && (
                <div className="flex items-center gap-2">
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                  <span className={daysRemaining < 3 && daysRemaining > 0 ? "text-orange-600 font-medium" : ""}>
                    {daysRemaining > 0 ? `${daysRemaining} dias restantes` : "Prazo vencido"}
                  </span>
                </div>
              )}
            </div>
          </div>

          {userRole === "admin" && (
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <svg className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                  />
                </svg>
                Editar Status
              </Button>
              <Button size="sm">
                <svg className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                  />
                </svg>
                Download Relatório
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
