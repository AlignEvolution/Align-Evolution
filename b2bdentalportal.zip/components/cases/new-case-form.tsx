"use client"

import type React from "react"

import type { User } from "@/lib/auth"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { FileUploadSection } from "./file-upload-section"
import { ClinicalPrescriptionForm } from "./clinical-prescription-form"
import type { ClinicalPrescription } from "@/lib/types"
import { useRouter } from "next/navigation"
import { createCase } from "@/lib/data-store"

interface NewCaseFormProps {
  dentist: User
}

type FormStep = "patient-info" | "prescription" | "file-upload"

interface FileRequirement {
  id: string
  label: string
  category: "stl" | "photo" | "pdf" | "radiograph"
  required: boolean
  uploaded: boolean
  file?: File
}

export function NewCaseForm({ dentist }: NewCaseFormProps) {
  const router = useRouter()
  const [currentStep, setCurrentStep] = useState<FormStep>("patient-info")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [patientName, setPatientName] = useState("")
  const [patientAge, setPatientAge] = useState("")
  const [notes, setNotes] = useState("")
  const [clinicalPrescription, setClinicalPrescription] = useState<ClinicalPrescription | null>(null)

  const [fileRequirements, setFileRequirements] = useState<FileRequirement[]>([
    { id: "stl-upper", label: "STL Arcada Superior", category: "stl", required: true, uploaded: false },
    { id: "stl-lower", label: "STL Arcada Inferior", category: "stl", required: true, uploaded: false },
    { id: "photo-frontal", label: "Foto Intraoral Frontal", category: "photo", required: false, uploaded: false },
    {
      id: "photo-lateral-right",
      label: "Foto Intraoral Lateral Direita",
      category: "photo",
      required: false,
      uploaded: false,
    },
    {
      id: "photo-lateral-left",
      label: "Foto Intraoral Lateral Esquerda",
      category: "photo",
      required: false,
      uploaded: false,
    },
    { id: "photo-occlusal-upper", label: "Foto Oclusal Superior", category: "photo", required: false, uploaded: false },
    { id: "photo-occlusal-lower", label: "Foto Oclusal Inferior", category: "photo", required: false, uploaded: false },
    {
      id: "radiograph-panoramic",
      label: "Radiografia Panorâmica",
      category: "radiograph",
      required: false,
      uploaded: false,
    },
    {
      id: "radiograph-lateral",
      label: "Radiografia Lateral",
      category: "radiograph",
      required: false,
      uploaded: false,
    },
    { id: "treatment-plan", label: "Plano de Tratamento (PDF)", category: "pdf", required: false, uploaded: false },
  ])

  const [additionalFiles, setAdditionalFiles] = useState<File[]>([])

  const handlePatientInfoNext = () => {
    if (!patientName.trim()) {
      setError("Nome do paciente é obrigatório")
      return
    }
    setError(null)
    setCurrentStep("prescription")
  }

  const handlePrescriptionComplete = (prescription: ClinicalPrescription) => {
    setClinicalPrescription(prescription)
    setCurrentStep("file-upload")
  }

  const handleFileUpload = (requirementId: string, file: File | null) => {
    setFileRequirements((prev) =>
      prev.map((req) => (req.id === requirementId ? { ...req, uploaded: !!file, file: file || undefined } : req)),
    )
  }

  const handleAdditionalFiles = (files: File[]) => {
    setAdditionalFiles((prev) => [...prev, ...files])
  }

  const removeAdditionalFile = (index: number) => {
    setAdditionalFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const validateForm = (): boolean => {
    if (!patientName.trim()) {
      setError("Nome do paciente é obrigatório")
      return false
    }

    if (!clinicalPrescription) {
      setError("Prescrição clínica é obrigatória")
      return false
    }

    const missingRequired = fileRequirements.filter((req) => req.required && !req.uploaded)
    if (missingRequired.length > 0) {
      setError(`Arquivos obrigatórios faltando: ${missingRequired.map((req) => req.label).join(", ")}`)
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!validateForm()) {
      return
    }

    setIsLoading(true)

    try {
      const uploadedFiles = await Promise.all(
        fileRequirements
          .filter((req) => req.file)
          .map(async (req) => {
            const dataUrl = await new Promise<string>((resolve, reject) => {
              const reader = new FileReader()
              reader.onload = () => resolve(reader.result as string)
              reader.onerror = reject
              reader.readAsDataURL(req.file!)
            })

            return {
              id: `f${Date.now()}-${req.id}`,
              name: req.file!.name,
              type: req.file!.type,
              size: req.file!.size,
              url: dataUrl, // Use persistent data URL instead of blob URL
              uploadedAt: new Date().toISOString(),
              uploadedBy: dentist.name,
              category: req.category,
            }
          }),
      )

      const additionalUploadedFiles = await Promise.all(
        additionalFiles.map(async (file, index) => {
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader()
            reader.onload = () => resolve(reader.result as string)
            reader.onerror = reject
            reader.readAsDataURL(file)
          })

          return {
            id: `f${Date.now()}-add-${index}`,
            name: file.name,
            type: file.type,
            size: file.size,
            url: dataUrl, // Use persistent data URL instead of blob URL
            uploadedAt: new Date().toISOString(),
            uploadedBy: dentist.name,
            category: file.type.includes("pdf") ? "pdf" : file.type.includes("image") ? "photo" : "other",
          }
        }),
      )

      const allFiles = [...uploadedFiles, ...additionalUploadedFiles]

      const newCase = createCase({
        patientName,
        patientAge,
        notes,
        dentistId: dentist.id,
        dentistName: dentist.name,
        clinicalPrescription: clinicalPrescription!,
        files: allFiles as any,
      })

      console.log("[v0] Case created successfully:", newCase.id, newCase.caseNumber)

      await new Promise((resolve) => setTimeout(resolve, 1000))

      router.push("/dashboard")
    } catch (error) {
      console.error("[v0] Error creating case:", error)
      setError("Erro ao criar o caso. Tente novamente.")
      setIsLoading(false)
    }
  }

  const requiredComplete = fileRequirements.filter((req) => req.required && req.uploaded).length
  const requiredTotal = fileRequirements.filter((req) => req.required).length
  const allRequiredUploaded = requiredComplete === requiredTotal
  const progressPercentage = requiredTotal > 0 ? (requiredComplete / requiredTotal) * 100 : 0

  if (currentStep === "patient-info") {
    return (
      <div className="space-y-6">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle>Informações do Paciente</CardTitle>
            <CardDescription>Dados básicos do paciente para identificação do caso</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="patientName">
                  Nome do Paciente <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="patientName"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="Ex: Maria Silva"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="patientAge">Idade</Label>
                <Input
                  id="patientAge"
                  type="number"
                  value={patientAge}
                  onChange={(e) => setPatientAge(e.target.value)}
                  placeholder="Ex: 28"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Observações Iniciais</Label>
              <textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Informações gerais sobre o paciente, histórico, etc."
                rows={4}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex items-center justify-between pt-6 border-t border-slate-200">
          <Button type="button" variant="outline" onClick={() => router.push("/dashboard")}>
            Cancelar
          </Button>

          <Button type="button" onClick={handlePatientInfoNext}>
            Próximo: Prescrição Clínica
          </Button>
        </div>
      </div>
    )
  }

  if (currentStep === "prescription") {
    return (
      <ClinicalPrescriptionForm onComplete={handlePrescriptionComplete} onBack={() => setCurrentStep("patient-info")} />
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card className="border-none shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Documentação Obrigatória</CardTitle>
              <CardDescription>Faça upload de todos os arquivos marcados como obrigatórios</CardDescription>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-slate-900">
                {requiredComplete}/{requiredTotal}
              </div>
              <div className="text-sm text-slate-600">Completos</div>
            </div>
          </div>

          <div className="mt-4">
            <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-300"
                style={{ width: progressPercentage + "%" }}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <h3 className="font-semibold text-slate-900 flex items-center gap-2">
              <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"
                />
              </svg>
              Modelos Digitais (STL)
            </h3>
            {fileRequirements
              .filter((req) => req.category === "stl")
              .map((req) => (
                <FileUploadItem key={req.id} requirement={req} onFileUpload={handleFileUpload} disabled={isLoading} />
              ))}
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-slate-900 flex items-center gap-2">
              <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 16l4.586-4.586a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"
                />
              </svg>
              Fotografias Intraorais
            </h3>
            {fileRequirements
              .filter((req) => req.category === "photo")
              .map((req) => (
                <FileUploadItem key={req.id} requirement={req} onFileUpload={handleFileUpload} disabled={isLoading} />
              ))}
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-slate-900 flex items-center gap-2">
              <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
              Radiografias (Opcional)
            </h3>
            {fileRequirements
              .filter((req) => req.category === "radiograph")
              .map((req) => (
                <FileUploadItem key={req.id} requirement={req} onFileUpload={handleFileUpload} disabled={isLoading} />
              ))}
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-slate-900 flex items-center gap-2">
              <svg className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"
                />
              </svg>
              Documentos PDF (Opcional)
            </h3>
            {fileRequirements
              .filter((req) => req.category === "pdf")
              .map((req) => (
                <FileUploadItem key={req.id} requirement={req} onFileUpload={handleFileUpload} disabled={isLoading} />
              ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle>Arquivos Adicionais</CardTitle>
          <CardDescription>Faça upload de outros arquivos relevantes (imagens, PDFs, DICOM, ZIP)</CardDescription>
        </CardHeader>
        <CardContent>
          <FileUploadSection onFilesAdded={handleAdditionalFiles} disabled={isLoading} multiple />

          {additionalFiles.length > 0 && (
            <div className="mt-4 space-y-2">
              <h4 className="font-medium text-sm text-slate-700">Arquivos adicionados:</h4>
              {additionalFiles.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <svg className="h-4 w-4 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"
                      />
                    </svg>
                    <span className="text-sm text-slate-700">{file.name}</span>
                    <span className="text-xs text-slate-500">({(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeAdditionalFile(index)}
                    disabled={isLoading}
                  >
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex items-center justify-between pt-6 border-t border-slate-200">
        <Button type="button" variant="outline" onClick={() => setCurrentStep("prescription")} disabled={isLoading}>
          Voltar
        </Button>

        <Button type="submit" disabled={isLoading || !allRequiredUploaded} className="min-w-[200px]">
          {isLoading ? (
            <>
              <svg className="animate-spin h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                />
              </svg>
              Criando caso...
            </>
          ) : (
            "Criar Caso"
          )}
        </Button>
      </div>

      {!allRequiredUploaded && (
        <p className="text-sm text-center text-orange-600">
          Complete o upload de todos os arquivos obrigatórios para continuar
        </p>
      )}
    </form>
  )
}

interface FileUploadItemProps {
  requirement: FileRequirement
  onFileUpload: (requirementId: string, file: File | null) => void
  disabled: boolean
}

function FileUploadItem({ requirement, onFileUpload, disabled }: FileUploadItemProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null
    onFileUpload(requirement.id, file)
  }

  const handleRemove = () => {
    onFileUpload(requirement.id, null)
  }

  const acceptedTypes = {
    stl: ".stl",
    photo: ".jpg,.jpeg,.png",
    pdf: ".pdf",
    radiograph: ".jpg,.jpeg,.png,.dcm,.dicom",
  }

  return (
    <div className="flex items-center justify-between p-3 border border-slate-200 rounded-lg hover:border-slate-300 transition-colors">
      <div className="flex items-center gap-3 flex-1">
        <Checkbox checked={requirement.uploaded} disabled />
        <div className="flex-1">
          <Label htmlFor={requirement.id} className="cursor-pointer">
            {requirement.label}
            {requirement.required && <span className="text-red-500 ml-1">*</span>}
          </Label>
          {requirement.file && (
            <p className="text-xs text-slate-500 mt-1">
              {requirement.file.name} ({(requirement.file.size / 1024 / 1024).toFixed(2)} MB)
            </p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2">
        {requirement.uploaded ? (
          <Button type="button" variant="ghost" size="sm" onClick={handleRemove} disabled={disabled}>
            <svg className="h-4 w-4 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </Button>
        ) : (
          <label htmlFor={requirement.id}>
            <Button type="button" size="sm" variant="outline" disabled={disabled} asChild>
              <span className="cursor-pointer">
                <svg className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                  />
                </svg>
                Upload
              </span>
            </Button>
            <input
              id={requirement.id}
              type="file"
              accept={acceptedTypes[requirement.category]}
              onChange={handleChange}
              className="hidden"
              disabled={disabled}
            />
          </label>
        )}
      </div>
    </div>
  )
}
