"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { FileText, Download } from "lucide-react"
import type { ClinicalPrescription } from "@/lib/types"

interface ClinicalPrescriptionViewerProps {
  prescription: ClinicalPrescription
  patientName: string
  caseNumber: string
}

export function ClinicalPrescriptionViewer({ prescription, patientName, caseNumber }: ClinicalPrescriptionViewerProps) {
  const handleDownloadPDF = () => {
    const content = `
PRESCRIÇÃO CLÍNICA PARA ALINHADORES
Align Evolution

═══════════════════════════════════════════════════════════

INFORMAÇÕES DO CASO

Paciente: ${patientName}
Número do Caso: ${caseNumber}
Data de Emissão: ${new Date().toLocaleDateString("pt-BR")}

═══════════════════════════════════════════════════════════

PRESCRIÇÃO CLÍNICA

1. ARCADAS A SEREM TRATADAS
   ${prescription.arches === "both" ? "Superior e Inferior" : prescription.arches === "upper" ? "Apenas Superior" : "Apenas Inferior"}

2. TIPO DE TRATAMENTO
   ${prescription.treatmentType === "both" ? "Anterior e Posterior" : prescription.treatmentType === "anterior" ? "Apenas Anterior" : "Apenas Posterior"}

3. SOBREMORDIDA (OVERBITE)
   ${prescription.overbite === "maintain" ? "Manter" : "Melhorar"}

4. LINHA MÉDIA
   ${prescription.midline === "maintain" ? "Manter" : "Melhorar"}

5. MORDIDA CRUZADA
   ${prescription.crossbite === "maintain" ? "Manter" : "Corrigir"}

6. DISTALIZAÇÃO
   ${prescription.distalization === "yes" ? "Sim" : "Não"}

7. USO DE ACESSÓRIOS (Elásticos)
   ${prescription.elastics === "yes" ? "Sim" : "Não"}

8. EXPANSÃO
   ${prescription.expansion === "yes" ? "Sim" : "Não"}

9. RELAÇÃO MOLAR
   Lado Esquerdo: ${prescription.molarRelationship.left === "maintain" ? "Manter" : "Melhorar"}
   Lado Direito: ${prescription.molarRelationship.right === "maintain" ? "Manter" : "Melhorar"}

10. RELAÇÃO CANINA
    Lado Esquerdo: ${prescription.canineRelationship.left === "maintain" ? "Manter" : "Melhorar"}
    Lado Direito: ${prescription.canineRelationship.right === "maintain" ? "Manter" : "Melhorar"}

11. IPR (Desgaste Interproximal)
    ${prescription.ipr.none ? "Nenhum" : [prescription.ipr.anterior && "Anterior", prescription.ipr.left && "Lado Esquerdo", prescription.ipr.right && "Lado Direito"].filter(Boolean).join(", ")}

12. RESTRIÇÕES DE MOVIMENTAÇÃO
    ${prescription.restrictedTeeth.length > 0 ? "Dentes: " + prescription.restrictedTeeth.join(", ") : "Nenhuma restrição"}

13. EXTRAÇÕES
    ${prescription.extractedTeeth.length > 0 ? "Dentes: " + prescription.extractedTeeth.join(", ") : "Nenhuma extração"}

14. OBSERVAÇÕES CLÍNICAS
    ${prescription.clinicalNotes || "Nenhuma observação adicional"}

═══════════════════════════════════════════════════════════

Este documento foi gerado eletronicamente pelo sistema Align Evolution
Data e hora da geração: ${new Date().toLocaleString("pt-BR")}
    `.trim()

    const blob = new Blob([content], { type: "text/plain;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `Prescricao_Clinica_${caseNumber}_${patientName.replace(/\s+/g, "_")}.txt`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const translateValue = (value: string, options: { [key: string]: string }) => {
    return options[value] || value
  }

  return (
    <Card className="p-6 bg-white shadow-sm border border-slate-200">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-100 rounded-lg">
            <FileText className="h-5 w-5 text-indigo-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900">Prescrição Clínica</h3>
            <p className="text-sm text-slate-500">Instruções para planejamento de alinhadores</p>
          </div>
        </div>
        <Button onClick={handleDownloadPDF} variant="outline" size="sm" className="gap-2 bg-transparent">
          <Download className="h-4 w-4" />
          Baixar PDF
        </Button>
      </div>

      <div className="space-y-4">
        {/* Arcadas */}
        <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
          <span className="text-xs font-semibold text-slate-500 min-w-[180px]">Arcadas:</span>
          <Badge variant="secondary">
            {translateValue(prescription.arches, {
              both: "Superior e Inferior",
              upper: "Apenas Superior",
              lower: "Apenas Inferior",
            })}
          </Badge>
        </div>

        {/* Tipo de Tratamento */}
        <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
          <span className="text-xs font-semibold text-slate-500 min-w-[180px]">Tipo de Tratamento:</span>
          <Badge variant="secondary">
            {translateValue(prescription.treatmentType, {
              both: "Anterior e Posterior",
              anterior: "Apenas Anterior",
              posterior: "Apenas Posterior",
            })}
          </Badge>
        </div>

        {/* Correções */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-slate-50 rounded-lg">
            <span className="text-xs font-semibold text-slate-500 block mb-2">Sobremordida:</span>
            <Badge variant={prescription.overbite === "improve" ? "default" : "secondary"}>
              {prescription.overbite === "maintain" ? "Manter" : "Melhorar"}
            </Badge>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <span className="text-xs font-semibold text-slate-500 block mb-2">Linha Média:</span>
            <Badge variant={prescription.midline === "improve" ? "default" : "secondary"}>
              {prescription.midline === "maintain" ? "Manter" : "Melhorar"}
            </Badge>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <span className="text-xs font-semibold text-slate-500 block mb-2">Mordida Cruzada:</span>
            <Badge variant={prescription.crossbite === "improve" ? "default" : "secondary"}>
              {prescription.crossbite === "maintain" ? "Manter" : "Corrigir"}
            </Badge>
          </div>
        </div>

        {/* Procedimentos */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 bg-slate-50 rounded-lg">
            <span className="text-xs font-semibold text-slate-500 block mb-2">Distalização:</span>
            <Badge variant={prescription.distalization === "yes" ? "default" : "outline"}>
              {prescription.distalization === "yes" ? "Sim" : "Não"}
            </Badge>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <span className="text-xs font-semibold text-slate-500 block mb-2">Elásticos:</span>
            <Badge variant={prescription.elastics === "yes" ? "default" : "outline"}>
              {prescription.elastics === "yes" ? "Sim" : "Não"}
            </Badge>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg">
            <span className="text-xs font-semibold text-slate-500 block mb-2">Expansão:</span>
            <Badge variant={prescription.expansion === "yes" ? "default" : "outline"}>
              {prescription.expansion === "yes" ? "Sim" : "Não"}
            </Badge>
          </div>
        </div>

        {/* Relações */}
        <div className="p-3 bg-slate-50 rounded-lg">
          <span className="text-xs font-semibold text-slate-500 block mb-2">Relação Molar:</span>
          <div className="flex gap-3">
            <div>
              <span className="text-xs text-slate-600">Esquerdo: </span>
              <Badge variant={prescription.molarRelationship.left === "improve" ? "default" : "secondary"}>
                {prescription.molarRelationship.left === "maintain" ? "Manter" : "Melhorar"}
              </Badge>
            </div>
            <div>
              <span className="text-xs text-slate-600">Direito: </span>
              <Badge variant={prescription.molarRelationship.right === "improve" ? "default" : "secondary"}>
                {prescription.molarRelationship.right === "maintain" ? "Manter" : "Melhorar"}
              </Badge>
            </div>
          </div>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg">
          <span className="text-xs font-semibold text-slate-500 block mb-2">Relação Canina:</span>
          <div className="flex gap-3">
            <div>
              <span className="text-xs text-slate-600">Esquerdo: </span>
              <Badge variant={prescription.canineRelationship.left === "improve" ? "default" : "secondary"}>
                {prescription.canineRelationship.left === "maintain" ? "Manter" : "Melhorar"}
              </Badge>
            </div>
            <div>
              <span className="text-xs text-slate-600">Direito: </span>
              <Badge variant={prescription.canineRelationship.right === "improve" ? "default" : "secondary"}>
                {prescription.canineRelationship.right === "maintain" ? "Manter" : "Melhorar"}
              </Badge>
            </div>
          </div>
        </div>

        {/* IPR */}
        <div className="p-3 bg-slate-50 rounded-lg">
          <span className="text-xs font-semibold text-slate-500 block mb-2">IPR (Desgaste Interproximal):</span>
          <div className="flex flex-wrap gap-2">
            {prescription.ipr.none ? (
              <Badge variant="outline">Nenhum</Badge>
            ) : (
              <>
                {prescription.ipr.anterior && <Badge>Anterior</Badge>}
                {prescription.ipr.left && <Badge>Lado Esquerdo</Badge>}
                {prescription.ipr.right && <Badge>Lado Direito</Badge>}
              </>
            )}
          </div>
        </div>

        {/* Restrições */}
        {prescription.restrictedTeeth.length > 0 && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <span className="text-xs font-semibold text-amber-800 block mb-2">Restrições de Movimentação:</span>
            <div className="flex flex-wrap gap-2">
              {prescription.restrictedTeeth.map((tooth) => (
                <Badge key={tooth} variant="outline" className="bg-amber-100 border-amber-300 text-amber-800">
                  Dente {tooth}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Extrações */}
        {prescription.extractedTeeth.length > 0 && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <span className="text-xs font-semibold text-red-800 block mb-2">Extrações:</span>
            <div className="flex flex-wrap gap-2">
              {prescription.extractedTeeth.map((tooth) => (
                <Badge key={tooth} variant="outline" className="bg-red-100 border-red-300 text-red-800">
                  Dente {tooth}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Observações */}
        {prescription.clinicalNotes && (
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <span className="text-xs font-semibold text-blue-800 block mb-2">Observações Clínicas:</span>
            <p className="text-sm text-blue-900 whitespace-pre-wrap">{prescription.clinicalNotes}</p>
          </div>
        )}
      </div>
    </Card>
  )
}
