"use client"

import type { CaseFile, Refinement } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface CaseFilesProps {
  files: CaseFile[]
  caseId: string
  refinements?: Refinement[]
}

export function CaseFiles({ files, refinements }: CaseFilesProps) {
  const handleDownload = (file: CaseFile) => {
    try {
      console.log("[v0] Starting download for file:", file.name)
      console.log("[v0] File URL type:", file.url.substring(0, 50))
      console.log("[v0] File URL length:", file.url.length)

      if (file.url === "#") {
        console.log("[v0] File URL is '#', skipping download")
        alert("Arquivo não disponível para download")
        return
      }

      if (file.url.startsWith("data:")) {
        try {
          console.log("[v0] Processing data URL for:", file.name)

          // Extract MIME type and data
          const commaIndex = file.url.indexOf(",")
          if (commaIndex === -1) {
            throw new Error("Invalid data URL format")
          }

          const metadata = file.url.substring(0, commaIndex)
          const data = file.url.substring(commaIndex + 1)

          console.log("[v0] Metadata:", metadata)
          console.log("[v0] Data length:", data.length)

          // Extract MIME type from metadata
          const mimeMatch = metadata.match(/:(.*?);/)
          const mimeType = mimeMatch ? mimeMatch[1] : "application/octet-stream"
          console.log("[v0] Extracted MIME type:", mimeType)

          // Decode base64
          let binaryString: string
          try {
            binaryString = atob(data)
            console.log("[v0] Successfully decoded base64, length:", binaryString.length)
          } catch (error) {
            console.error("[v0] Failed to decode base64:", error)
            throw new Error("Base64 decoding failed")
          }

          // Convert to Uint8Array
          const bytes = new Uint8Array(binaryString.length)
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i)
          }
          console.log("[v0] Converted to Uint8Array, size:", bytes.length)

          // Create Blob
          const blob = new Blob([bytes], { type: mimeType })
          console.log("[v0] Created blob with size:", blob.size)

          // Create object URL
          const objectUrl = URL.createObjectURL(blob)
          console.log("[v0] Created object URL:", objectUrl.substring(0, 50))

          // Create download link
          const link = document.createElement("a")
          link.href = objectUrl
          link.download = file.name
          link.style.display = "none"

          document.body.appendChild(link)
          console.log("[v0] Triggering download for:", file.name)
          link.click()
          document.body.removeChild(link)

          // Clean up object URL
          setTimeout(() => {
            URL.revokeObjectURL(objectUrl)
            console.log("[v0] Revoked object URL")
          }, 100)

          console.log("[v0] Download completed successfully for:", file.name)
        } catch (dataUrlError) {
          console.error("[v0] Error processing data URL:", dataUrlError)
          alert(`Erro ao processar arquivo: ${dataUrlError instanceof Error ? dataUrlError.message : "Unknown error"}`)
        }
      } else {
        console.log("[v0] Processing regular URL for:", file.name)
        try {
          const link = document.createElement("a")
          link.href = file.url
          link.download = file.name
          link.style.display = "none"

          document.body.appendChild(link)
          console.log("[v0] Triggering download via regular URL for:", file.name)
          link.click()
          document.body.removeChild(link)
          console.log("[v0] Regular URL download completed for:", file.name)
        } catch (urlError) {
          console.error("[v0] Error downloading from regular URL:", urlError)
          alert("Erro ao baixar arquivo. Tente novamente.")
        }
      }
    } catch (error) {
      console.error("[v0] Unexpected error in handleDownload:", error)
      alert("Erro inesperado ao baixar arquivo. Por favor tente novamente.")
    }
  }

  const getFileIcon = (category: CaseFile["category"]) => {
    switch (category) {
      case "stl":
        return (
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"
            />
          </svg>
        )
      case "photo":
        return (
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
            />
          </svg>
        )
      case "pdf":
        return (
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2-2v14a2 2 0 002 2z"
            />
          </svg>
        )
      case "radiograph":
        return (
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            />
          </svg>
        )
      default:
        return (
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            />
          </svg>
        )
    }
  }

  const getCategoryLabel = (category: CaseFile["category"]) => {
    const labels = {
      stl: "Modelo 3D",
      photo: "Fotografia",
      pdf: "Documento",
      radiograph: "Radiografia",
      other: "Outro",
    }
    return labels[category]
  }

  const allFiles = [...files]
  if (refinements && refinements.length > 0) {
    refinements.forEach((refinement, index) => {
      refinement.files.forEach((file) => {
        allFiles.push({
          ...file,
          refinementNumber: index + 1,
        } as CaseFile & { refinementNumber: number })
      })
    })
  }

  const groupedFiles = allFiles.reduce(
    (acc, file) => {
      if (!acc[file.category]) {
        acc[file.category] = []
      }
      acc[file.category].push(file)
      return acc
    },
    {} as Record<string, (CaseFile & { refinementNumber?: number })[]>,
  )

  return (
    <Card className="border-none shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Arquivos do Caso</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        {allFiles.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <svg
              className="h-12 w-12 mx-auto mb-3 text-slate-300"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
            <p>Nenhum arquivo enviado ainda</p>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedFiles).map(([category, categoryFiles]) => (
              <div key={category}>
                <h3 className="font-medium text-slate-700 mb-3 flex items-center gap-2">
                  {getFileIcon(category as CaseFile["category"])}
                  {getCategoryLabel(category as CaseFile["category"])} ({categoryFiles.length})
                </h3>
                <div className="space-y-2">
                  {categoryFiles.map((file) => (
                    <div
                      key={file.id}
                      className="flex items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                    >
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="flex-shrink-0 w-10 h-10 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
                          {getFileIcon(file.category)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium text-slate-900 truncate">{file.name}</p>
                            {file.refinementNumber && (
                              <Badge variant="secondary" className="text-xs">
                                Refinamento {file.refinementNumber}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-slate-500">
                            {(file.size / 1024 / 1024).toFixed(2)} MB •{" "}
                            {new Date(file.uploadedAt).toLocaleDateString("pt-BR")} • {file.uploadedBy}
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => handleDownload(file)}>
                        <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                          />
                        </svg>
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
