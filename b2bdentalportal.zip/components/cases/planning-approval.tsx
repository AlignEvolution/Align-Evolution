"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { ExternalLink, CheckCircle2, XCircle, Eye } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface PlanningApprovalProps {
  caseId: string
  planningUrl: string
  version?: number
  status: string
  onApprove: (notes?: string) => void
  onRequestChanges: (reason: string) => void
}

export function PlanningApproval({
  caseId,
  planningUrl,
  version = 1,
  status,
  onApprove,
  onRequestChanges,
}: PlanningApprovalProps) {
  const [showApproval, setShowApproval] = useState(false)
  const [showRejection, setShowRejection] = useState(false)
  const [notes, setNotes] = useState("")
  const [reason, setReason] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  console.log("[v0] PlanningApproval rendered for case:", caseId, "with URL:", planningUrl)

  const handleOpenViewer = () => {
    console.log("[v0] Opening planning URL:", planningUrl)
    window.open(planningUrl, "_blank", "noopener,noreferrer")
  }

  const handleApprove = async () => {
    setIsSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800))
    onApprove(notes)
    setIsSubmitting(false)
    setShowApproval(false)
  }

  const handleRequestChanges = async () => {
    if (!reason.trim()) return

    setIsSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800))
    onRequestChanges(reason)
    setIsSubmitting(false)
    setShowRejection(false)
    setReason("")
  }

  const isAwaitingApproval = status === "awaiting_approval" || status === "planning"

  return (
    <Card className="p-6 bg-gradient-to-br from-indigo-50 to-blue-50 border-indigo-200 shadow-sm">
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <Eye className="h-5 w-5 text-indigo-600" />
            Visualização do Planejamento (v{version})
          </h3>
          <p className="text-sm text-slate-600 mt-1">Visualize o planejamento 3D e aprove ou solicite alterações</p>
        </div>

        <div className="bg-white rounded-lg p-4 border border-indigo-200">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-indigo-600 uppercase tracking-wide">Link de Visualização</span>
            {isAwaitingApproval && (
              <span className="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded-full font-medium">
                Aguardando sua aprovação
              </span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-mono text-slate-700 truncate">{planningUrl}</p>
            </div>
            <Button size="sm" onClick={handleOpenViewer} className="bg-indigo-600 hover:bg-indigo-700 shrink-0">
              <ExternalLink className="h-4 w-4 mr-2" />
              Abrir Visualizador
            </Button>
          </div>
        </div>

        {isAwaitingApproval && !showApproval && !showRejection && (
          <Alert className="bg-amber-50 border-amber-200">
            <AlertDescription className="text-sm text-amber-800">
              Por favor, revise o planejamento cuidadosamente antes de aprovar ou solicitar alterações.
            </AlertDescription>
          </Alert>
        )}

        {!showApproval && !showRejection && isAwaitingApproval && (
          <div className="flex gap-3 pt-2">
            <Button onClick={() => setShowApproval(true)} className="flex-1 bg-emerald-600 hover:bg-emerald-700">
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Aprovar Planejamento
            </Button>
            <Button
              onClick={() => setShowRejection(true)}
              variant="outline"
              className="flex-1 border-red-300 text-red-600 hover:bg-red-50"
            >
              <XCircle className="h-4 w-4 mr-2" />
              Solicitar Alterações
            </Button>
          </div>
        )}

        {showApproval && (
          <div className="space-y-3 pt-2 border-t border-indigo-200">
            <div>
              <label className="text-sm font-medium text-slate-700 mb-2 block">Observações adicionais (opcional)</label>
              <Textarea
                placeholder="Ex: Excelente trabalho! Pode seguir para produção."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="resize-none"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleApprove} disabled={isSubmitting} className="bg-emerald-600 hover:bg-emerald-700">
                <CheckCircle2 className="h-4 w-4 mr-2" />
                {isSubmitting ? "Aprovando..." : "Confirmar Aprovação"}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowApproval(false)
                  setNotes("")
                }}
              >
                Cancelar
              </Button>
            </div>
          </div>
        )}

        {showRejection && (
          <div className="space-y-3 pt-2 border-t border-indigo-200">
            <div>
              <label className="text-sm font-medium text-slate-700 mb-2 block">
                Descreva as alterações necessárias *
              </label>
              <Textarea
                placeholder="Ex: O overjet está um pouco excessivo no setor anterior. Por favor, reduzir em 1mm."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={4}
                className="resize-none"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleRequestChanges} disabled={isSubmitting || !reason.trim()} variant="destructive">
                <XCircle className="h-4 w-4 mr-2" />
                {isSubmitting ? "Enviando..." : "Enviar Solicitação de Alterações"}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowRejection(false)
                  setReason("")
                }}
              >
                Cancelar
              </Button>
            </div>
          </div>
        )}
      </div>
    </Card>
  )
}
