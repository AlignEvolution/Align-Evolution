"use client"

import type { Refinement } from "@/lib/types"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, Clock, ExternalLink, FileText } from "lucide-react"
import { approveRefinement } from "@/lib/data-store"

interface RefinementsListProps {
  caseId: string
  refinements: Refinement[]
  isAdmin: boolean
  userName: string
  onUpdate?: () => void
}

export function RefinementsList({ caseId, refinements, isAdmin, userName, onUpdate }: RefinementsListProps) {
  if (!refinements || refinements.length === 0) return null

  const handleApprove = (refinementId: string) => {
    approveRefinement(caseId, refinementId, userName)
    onUpdate?.()
    window.location.reload()
  }

  const handleOpenPlanning = (url: string) => {
    console.log("[v0] Opening refinement planning URL:", url)
    window.open(url, "_blank", "noopener,noreferrer")
  }

  const handleDownloadFile = (file: { id: string; name: string; url: string }) => {
    console.log("[v0] Downloading refinement file:", file.name)
    const link = document.createElement("a")
    link.href = file.url
    link.download = file.name
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
        <FileText className="h-5 w-5 text-purple-600" />
        Refinamentos ({refinements.length})
      </h3>

      {refinements.map((refinement, index) => (
        <Card key={refinement.id} className="p-6 border-purple-200 bg-gradient-to-br from-purple-50 to-white">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h4 className="font-semibold text-slate-900">Refinamento #{index + 1}</h4>
              <p className="text-sm text-slate-600 mt-1">
                Solicitado em {new Date(refinement.requestedAt).toLocaleDateString("pt-BR")}
              </p>
            </div>
            <StatusBadge status={refinement.status} />
          </div>

          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-slate-700">Motivo:</p>
              <p className="text-sm text-slate-600 mt-1">{refinement.reason}</p>
            </div>

            <div>
              <p className="text-sm font-medium text-slate-700 mb-2">Arquivos enviados: {refinement.files.length}</p>
              <div className="grid grid-cols-2 gap-2">
                {refinement.files.slice(0, 4).map((file) => (
                  <button
                    key={file.id}
                    onClick={() => handleDownloadFile(file)}
                    className="text-xs p-2 bg-white rounded border border-slate-200 truncate hover:bg-slate-50 hover:border-blue-400 transition-colors cursor-pointer text-left"
                    title={file.name + " - Clique para baixar"}
                  >
                    📎 {file.name}
                  </button>
                ))}
              </div>
              {refinement.files.length > 4 && (
                <p className="text-xs text-slate-500 mt-2">+{refinement.files.length - 4} arquivos adicionais</p>
              )}
            </div>

            {refinement.planningUrl && (
              <div className="pt-3 border-t border-purple-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-700">Planejamento de Refinamento</p>
                    <p className="text-xs text-slate-600 mt-1">Versão {refinement.planningVersion || 1}</p>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleOpenPlanning(refinement.planningUrl!)}
                    className="bg-gradient-to-r from-blue-600 to-indigo-600"
                  >
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Abrir Visualizador
                  </Button>
                </div>

                {!isAdmin && refinement.status === "awaiting_approval" && (
                  <div className="mt-4 flex gap-2">
                    <Button
                      onClick={() => handleApprove(refinement.id)}
                      className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600"
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Aprovar Refinamento
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Timeline */}
          <div className="mt-4 pt-4 border-t border-purple-200">
            <p className="text-xs font-medium text-slate-700 mb-2">Histórico:</p>
            <div className="space-y-2">
              {refinement.timeline.map((event) => (
                <div key={event.id} className="flex items-start gap-2 text-xs">
                  <Clock className="h-3 w-3 text-slate-400 mt-0.5" />
                  <div>
                    <p className="text-slate-700">{event.title}</p>
                    <p className="text-slate-500">
                      {new Date(event.timestamp).toLocaleString("pt-BR")} - {event.user}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}

function StatusBadge({ status }: { status: Refinement["status"] }) {
  const configs = {
    requested: { label: "Solicitado", color: "bg-orange-100 text-orange-700 border-orange-200" },
    planning: { label: "Em Planejamento", color: "bg-blue-100 text-blue-700 border-blue-200" },
    awaiting_approval: { label: "Aguardando Aprovação", color: "bg-purple-100 text-purple-700 border-purple-200" },
    approved: { label: "Aprovado", color: "bg-green-100 text-green-700 border-green-200" },
    completed: { label: "Concluído", color: "bg-slate-100 text-slate-700 border-slate-200" },
  }

  const config = configs[status]

  return <span className={`px-3 py-1 rounded-full text-xs font-medium border ${config.color}`}>{config.label}</span>
}
