"use client"

import { useState } from "react"
import type { CaseStatus } from "@/lib/types"
import { updateCaseStatus } from "@/lib/data-store"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"

interface CaseStatusPipelineProps {
  status: CaseStatus
  caseId?: string
  onStatusChange?: (newStatus: CaseStatus) => void
  isAdmin?: boolean
  userName?: string
}

const PIPELINE_STAGES: { status: CaseStatus; label: string }[] = [
  { status: "received", label: "Recebido" },
  { status: "planning", label: "Planejamento" },
  { status: "awaiting_approval", label: "Aprovação" },
  { status: "approved", label: "Aprovado" },
  { status: "in_production", label: "Produção" },
  { status: "shipped", label: "Enviado" },
  { status: "delivered", label: "Entregue" },
  { status: "refinement", label: "Refinamento" },
]

export function CaseStatusPipeline({
  status,
  caseId,
  onStatusChange,
  isAdmin = false,
  userName = "Admin",
}: CaseStatusPipelineProps) {
  const [isChanging, setIsChanging] = useState(false)
  const [selectedStatus, setSelectedStatus] = useState<CaseStatus>(status)

  const isPending = status === "pending"
  const isCompleted = status === "completed"
  const currentIndex = PIPELINE_STAGES.findIndex((stage) => stage.status === status)
  const progressWidth = currentIndex >= 0 ? (currentIndex / (PIPELINE_STAGES.length - 1)) * 100 : 0

  const handleStatusChange = () => {
    if (!caseId || !isAdmin || selectedStatus === status) return

    setIsChanging(true)
    try {
      const result = updateCaseStatus(caseId, selectedStatus, userName)
      if (result) {
        console.log("[v0] Case status updated to:", selectedStatus)
        onStatusChange?.(selectedStatus)
      }
    } catch (error) {
      console.error("[v0] Error updating status:", error)
    } finally {
      setIsChanging(false)
    }
  }

  if (isPending || isCompleted) {
    return (
      <div className="bg-white rounded-lg p-6 shadow-sm">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-orange-100 to-orange-50 border border-orange-200">
            <svg className="h-5 w-5 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
              />
            </svg>
            <span className="font-medium text-orange-900">
              {isPending && "Documentação Pendente"}
              {isCompleted && "Caso Finalizado"}
            </span>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-slate-900">Pipeline do Caso</h2>
        {isAdmin && (
          <div className="flex items-center gap-2">
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PIPELINE_STAGES.map((stage) => (
                  <SelectItem key={stage.status} value={stage.status}>
                    {stage.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button size="sm" onClick={handleStatusChange} disabled={selectedStatus === status || isChanging}>
              {isChanging ? "Atualizando..." : "Atualizar"}
            </Button>
          </div>
        )}
      </div>

      <div className="relative">
        <div className="absolute top-5 left-0 right-0 h-1 bg-slate-200" />
        <div
          className="absolute top-5 left-0 h-1 bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-500"
          style={{ width: progressWidth + "%" }}
        />

        <div className="relative flex justify-between">
          {PIPELINE_STAGES.map((stage, index) => {
            const isActive = index === currentIndex
            const isCompleted = index < currentIndex
            const isPast = index < currentIndex

            return (
              <div key={stage.status} className="flex flex-col items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                    isActive
                      ? "bg-gradient-to-br from-blue-600 to-indigo-600 border-blue-600 scale-110 shadow-lg"
                      : isCompleted
                        ? "bg-blue-600 border-blue-600"
                        : "bg-white border-slate-300"
                  }`}
                >
                  {isCompleted || isActive ? (
                    <svg className="h-5 w-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                  ) : (
                    <div className="w-3 h-3 rounded-full bg-slate-300" />
                  )}
                </div>

                <p
                  className={`mt-3 text-xs text-center font-medium transition-colors ${
                    isActive ? "text-blue-600" : isPast ? "text-slate-700" : "text-slate-500"
                  }`}
                >
                  {stage.label}
                </p>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
