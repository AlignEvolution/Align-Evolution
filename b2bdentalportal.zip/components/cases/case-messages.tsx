"use client"

import type React from "react"

import type { Message } from "@/lib/types"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface CaseMessagesProps {
  messages: Message[]
  caseId: string
  currentUserId: string
}

export function CaseMessages({ messages, currentUserId }: CaseMessagesProps) {
  const [newMessage, setNewMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const sortedMessages = [...messages].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    setIsSubmitting(true)
    // Simulate message sending
    await new Promise((resolve) => setTimeout(resolve, 1000))
    console.log("[v0] Sending message:", newMessage)
    setNewMessage("")
    setIsSubmitting(false)
  }

  return (
    <Card className="border-none shadow-sm sticky top-24">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Mensagens</CardTitle>
          {messages.some((m) => !m.isRead && m.userId !== currentUserId) && (
            <Badge className="bg-green-600 hover:bg-green-700">
              {messages.filter((m) => !m.isRead && m.userId !== currentUserId).length} nova(s)
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {/* Messages list */}
        <div className="space-y-4 mb-4 max-h-96 overflow-y-auto">
          {sortedMessages.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <svg
                className="h-10 w-10 mx-auto mb-2 text-slate-300"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                />
              </svg>
              <p className="text-sm">Nenhuma mensagem ainda</p>
            </div>
          ) : (
            sortedMessages.map((message) => {
              const isOwnMessage = message.userId === currentUserId

              return (
                <div key={message.id} className={`flex ${isOwnMessage ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[85%] ${isOwnMessage ? "order-2" : "order-1"}`}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-slate-700">{message.userName}</span>
                      <Badge variant="secondary" className="text-xs">
                        {message.userRole === "admin" ? "Align Evolution" : "Dentista"}
                      </Badge>
                    </div>
                    <div
                      className={`p-3 rounded-lg ${
                        isOwnMessage ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-900"
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      {new Date(message.timestamp).toLocaleDateString("pt-BR", {
                        day: "2-digit",
                        month: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              )
            })
          )}
        </div>

        {/* Message input */}
        <form onSubmit={handleSubmit} className="space-y-3 border-t border-slate-200 pt-4">
          <textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Digite sua mensagem..."
            rows={3}
            disabled={isSubmitting}
            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none text-sm"
          />

          <div className="flex items-center justify-between gap-2">
            <Button type="button" variant="outline" size="sm" disabled={isSubmitting}>
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"
                />
              </svg>
            </Button>

            <Button type="submit" size="sm" disabled={isSubmitting || !newMessage.trim()} className="flex-1">
              {isSubmitting ? "Enviando..." : "Enviar"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
