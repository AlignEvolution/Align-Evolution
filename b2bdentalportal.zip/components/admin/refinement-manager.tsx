"use client"

import { useState } from "react"
import type { Refinement } from "@/lib/types"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ExternalLink, Save } from "lucide-react"
import { updateRefinementPlanningUrl } from "@/lib/data-store"

interface RefinementManagerProps {
  caseId: string
  refinement: Refinement
  onUpdate?: () => void
}

export function RefinementManager({ caseId, refinement, onUpdate }: RefinementManagerProps) {
  const [planningUrl, setPlanningUrl] = useState(refinement.planningUrl || "")
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    if (!planningUrl.trim()) return

    setIsSaving(true)
    try {
      const result = updateRefinementPlanningUrl(caseId, refinement.id, planningUrl)
      if (result) {
        onUpdate?.()
        window.location.reload()
      }
    } catch (error) {
      console.error("Error saving refinement planning URL:", error)
    } finally {
      setIsSaving(false)
    }
  }

  const handleTest = () => {
    if (planningUrl.trim()) {
      window.open(planningUrl, "_blank", "noopener,noreferrer")
    }
  }

  if (refinement.status === "completed") {
    return null
  }

  return (
    <Card className="p-4 bg-gradient-to-br from-purple-50 to-white border-purple-200">
      <h4 className="text-sm font-semibold text-slate-900 mb-3">URL do Planejamento de Refinamento</h4>
      <div className="flex gap-2">
        <Input
          type="url"
          value={planningUrl}
          onChange={(e) => setPlanningUrl(e.target.value)}
          placeholder="https://..."
          className="flex-1"
        />
        <Button onClick={handleTest} variant="outline" size="sm" disabled={!planningUrl.trim()}>
          <ExternalLink className="h-4 w-4" />
        </Button>
        <Button onClick={handleSave} size="sm" disabled={isSaving || !planningUrl.trim()}>
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? "Salvando..." : "Salvar"}
        </Button>
      </div>
      {refinement.planningUrl && (
        <p className="text-xs text-slate-600 mt-2">Versão atual: {refinement.planningVersion || 1}</p>
      )}
    </Card>
  )
}
