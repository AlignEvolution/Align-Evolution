"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { ExternalLink, Save, Edit2, CheckCircle2 } from "lucide-react"
import { updatePlanningUrl } from "@/lib/data-store"

interface PlanningUrlManagerProps {
  caseId: string
  currentUrl?: string
  version?: number
  onSave: (url: string) => void
}

export function PlanningUrlManager({ caseId, currentUrl, version = 1, onSave }: PlanningUrlManagerProps) {
  const [isEditing, setIsEditing] = useState(!currentUrl)
  const [url, setUrl] = useState(currentUrl || "")
  const [isSaving, setIsSaving] = useState(false)

  const handleSave = async () => {
    if (!url.trim()) return

    setIsSaving(true)
    console.log("[v0] Admin saving planning URL:", url)

    const updated = updatePlanningUrl(caseId, url, version)

    if (updated) {
      console.log("[v0] Planning URL saved successfully:", updated)
      onSave(url)
      setIsEditing(false)
      // Force page refresh to show updated data
      window.location.reload()
    } else {
      console.error("[v0] Failed to save planning URL")
    }

    setIsSaving(false)
  }

  const handleOpenUrl = () => {
    if (currentUrl) {
      console.log("[v0] Admin opening planning URL:", currentUrl)
      window.open(currentUrl, "_blank", "noopener,noreferrer")
    }
  }

  return (
    <Card className="p-6 bg-white border-slate-200 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-slate-900">URL de Visualização do Planejamento</h3>
          <p className="text-sm text-slate-600 mt-1">
            Compartilhe o link da visualização 3D para aprovação do dentista
          </p>
        </div>
        {currentUrl && !isEditing && (
          <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
            <Edit2 className="h-4 w-4 mr-2" />
            Editar
          </Button>
        )}
      </div>

      {isEditing ? (
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-slate-700 mb-2 block">
              URL do Planejamento (versão {version})
            </label>
            <Input
              type="url"
              placeholder="https://viewer.exemplo.com/case/123abc"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="font-mono text-sm"
            />
            <p className="text-xs text-slate-500 mt-2">
              Cole o link gerado pelo seu software de planejamento (ex: Clincheck, uDesign, etc.)
            </p>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={handleSave}
              disabled={isSaving || !url.trim()}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              <Save className="h-4 w-4 mr-2" />
              {isSaving ? "Salvando..." : "Salvar e Enviar para Aprovação"}
            </Button>
            {currentUrl && (
              <Button
                variant="outline"
                onClick={() => {
                  setUrl(currentUrl)
                  setIsEditing(false)
                }}
              >
                Cancelar
              </Button>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <div className="flex items-center justify-between">
            <div className="flex-1 min-w-0">
              <p className="text-xs text-slate-500 mb-1">URL Ativa (v{version})</p>
              <p className="text-sm font-mono text-slate-900 truncate">{currentUrl}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={handleOpenUrl}>
              <ExternalLink className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex items-center gap-2 mt-3 text-sm text-emerald-600">
            <CheckCircle2 className="h-4 w-4" />
            <span>Enviado para aprovação do dentista</span>
          </div>
        </div>
      )}
    </Card>
  )
}
