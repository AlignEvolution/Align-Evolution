"use client"

import type { Case, CaseStatus } from "@/lib/types"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getStatusConfig } from "@/lib/utils/case-status"
import Link from "next/link"

interface AdminCasesTableProps {
  cases: Case[]
  initialFilter?: CaseStatus | "all" | "overdue" | "refinements"
}

export function AdminCasesTable({ cases, initialFilter = "all" }: AdminCasesTableProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<CaseStatus | "all" | "overdue" | "refinements">(initialFilter)
  const [sortBy, setSortBy] = useState<"date" | "priority" | "status">("date")

  useEffect(() => {
    setStatusFilter(initialFilter)
  }, [initialFilter])

  let filteredCases = cases.filter((c) => {
    const matchesSearch =
      c.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.caseNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.dentistName.toLowerCase().includes(searchQuery.toLowerCase())

    let matchesStatus = false
    if (statusFilter === "all") {
      matchesStatus = true
    } else if (statusFilter === "overdue") {
      matchesStatus = c.dueDate && new Date(c.dueDate) < new Date()
    } else if (statusFilter === "refinements") {
      matchesStatus =
        c.refinements !== undefined && c.refinements.some((r) => r.status === "pending" || r.status === "planning")
    } else if (statusFilter === "awaiting_dentist") {
      matchesStatus = c.awaitingDentist === true
    } else {
      matchesStatus = c.status === statusFilter
    }

    return matchesSearch && matchesStatus
  })

  filteredCases = [...filteredCases].sort((a, b) => {
    switch (sortBy) {
      case "date":
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      case "priority":
        const priorityOrder = { high: 3, medium: 2, low: 1 }
        return priorityOrder[b.priority] - priorityOrder[a.priority]
      case "status":
        return a.status.localeCompare(b.status)
      default:
        return 0
    }
  })

  return (
    <Card className="border-none shadow-sm">
      <CardHeader>
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <CardTitle>Todos os Casos</CardTitle>

          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              placeholder="Buscar por paciente, caso ou dentista..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="sm:w-80"
            />

            <Select
              value={statusFilter}
              onValueChange={(value) => setStatusFilter(value as CaseStatus | "all" | "overdue" | "refinements")}
            >
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="received">Recebido</SelectItem>
                <SelectItem value="pending">Pendência</SelectItem>
                <SelectItem value="planning">Em Planejamento</SelectItem>
                <SelectItem value="awaiting_dentist">Aguardando Aprovação</SelectItem>
                <SelectItem value="awaiting_approval">Aprovados pelo Dentista</SelectItem>
                <SelectItem value="approved">Aprovado</SelectItem>
                <SelectItem value="in_production">Em Produção</SelectItem>
                <SelectItem value="shipped">Enviado</SelectItem>
                <SelectItem value="delivered">Entregue</SelectItem>
                <SelectItem value="refinement">Refinamento</SelectItem>
                <SelectItem value="completed">Finalizado</SelectItem>
                <SelectItem value="overdue">Atrasados</SelectItem>
                <SelectItem value="refinements">Com Refinamento</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={(value) => setSortBy(value as "date" | "priority" | "status")}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="Ordenar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Data</SelectItem>
                <SelectItem value="priority">Prioridade</SelectItem>
                <SelectItem value="status">Status</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {filteredCases.length === 0 ? (
          <div className="text-center py-12 text-slate-500">
            <svg
              className="h-16 w-16 mx-auto mb-4 text-slate-300"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
            <p className="font-medium mb-1">Nenhum caso encontrado</p>
            <p className="text-sm">Tente ajustar os filtros de busca</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-4 font-semibold text-sm text-slate-700">Paciente</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm text-slate-700">Número do Caso</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm text-slate-700">Dentista</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm text-slate-700">Status</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm text-slate-700">Prioridade</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm text-slate-700">Data</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm text-slate-700">Prazo</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm text-slate-700">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredCases.map((caseItem) => {
                  const statusConfig = getStatusConfig(caseItem.status)
                  const daysRemaining = caseItem.dueDate
                    ? Math.ceil((new Date(caseItem.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
                    : null

                  const hasPendingRefinement =
                    caseItem.refinements &&
                    caseItem.refinements.some((r) => r.status === "pending" || r.status === "planning")

                  return (
                    <tr key={caseItem.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-slate-900">{caseItem.patientName}</span>
                          {caseItem.hasUnreadMessages && (
                            <div className="h-2 w-2 bg-green-600 rounded-full" title="Mensagens não lidas" />
                          )}
                          {hasPendingRefinement && (
                            <Badge className="bg-teal-100 text-teal-700 hover:bg-teal-100 text-xs">
                              <svg className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                                />
                              </svg>
                              Refinamento
                            </Badge>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="secondary" className="text-xs">
                          {caseItem.caseNumber}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-sm text-slate-600">{caseItem.dentistName}</td>
                      <td className="py-3 px-4">
                        <Badge
                          className={`${statusConfig.bgColor} ${statusConfig.color} hover:${statusConfig.bgColor} text-xs`}
                        >
                          {statusConfig.label}
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        {caseItem.priority === "high" && (
                          <Badge variant="destructive" className="text-xs">
                            Alta
                          </Badge>
                        )}
                        {caseItem.priority === "medium" && (
                          <Badge className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100 text-xs">Média</Badge>
                        )}
                        {caseItem.priority === "low" && (
                          <Badge className="bg-slate-100 text-slate-700 hover:bg-slate-100 text-xs">Baixa</Badge>
                        )}
                      </td>
                      <td className="py-3 px-4 text-sm text-slate-600">
                        {new Date(caseItem.createdAt).toLocaleDateString("pt-BR")}
                      </td>
                      <td className="py-3 px-4">
                        {daysRemaining !== null && (
                          <span
                            className={`text-sm ${
                              daysRemaining < 0
                                ? "text-red-600 font-medium"
                                : daysRemaining < 3
                                  ? "text-orange-600 font-medium"
                                  : "text-slate-600"
                            }`}
                          >
                            {daysRemaining > 0 ? `${daysRemaining}d` : "Atrasado"}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <Link href={`/admin/casos/${caseItem.id}`}>
                          <Button variant="ghost" size="sm">
                            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                              />
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                              />
                            </svg>
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
