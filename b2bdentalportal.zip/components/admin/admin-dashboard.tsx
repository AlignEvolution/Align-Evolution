"use client"

import { useState } from "react"
import { AdminStats } from "@/components/admin/admin-stats"
import { AdminCasesTable } from "@/components/admin/admin-cases-table"
import type { Case, CaseStatus } from "@/lib/types"

interface AdminDashboardProps {
  cases: Case[]
}

export function AdminDashboard({ cases }: AdminDashboardProps) {
  const [activeFilter, setActiveFilter] = useState<CaseStatus | "all" | "overdue" | "refinements">("all")

  // Calculate admin statistics
  const totalCases = cases.length
  const statusCounts = cases.reduce(
    (acc, c) => {
      acc[c.status] = (acc[c.status] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  const casesWithPendingRefinements = cases.filter(
    (c) => c.refinements && c.refinements.some((r) => r.status === "pending" || r.status === "planning"),
  ).length

  const stats = {
    total: totalCases,
    received: statusCounts.received || 0,
    pending: statusCounts.pending || 0,
    planning: statusCounts.planning || 0,
    awaitingApproval: statusCounts.awaiting_approval || 0,
    inProduction: statusCounts.in_production || 0,
    shipped: statusCounts.shipped || 0,
    refinements: casesWithPendingRefinements,
    awaitingDentist: cases.filter((c) => c.awaitingDentist).length,
    overdue: cases.filter((c) => c.dueDate && new Date(c.dueDate) < new Date()).length,
  }

  return (
    <>
      <AdminStats stats={stats} onFilterClick={setActiveFilter} activeFilter={activeFilter} />
      <AdminCasesTable cases={cases} initialFilter={activeFilter} />
    </>
  )
}
