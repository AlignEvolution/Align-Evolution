"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { DentistEditForm } from "./dentist-edit-form"
import type { Dentist } from "@/lib/types"

interface DentistEditDialogProps {
  dentist: Dentist
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: (dentist: Dentist) => void
}

export function DentistEditDialog({ dentist, open, onOpenChange, onSuccess }: DentistEditDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Cadastro do Dentista</DialogTitle>
        </DialogHeader>
        <DentistEditForm
          dentist={dentist}
          onClose={() => onOpenChange(false)}
          onSuccess={(updatedDentist) => {
            onSuccess?.(updatedDentist)
            onOpenChange(false)
          }}
        />
      </DialogContent>
    </Dialog>
  )
}
