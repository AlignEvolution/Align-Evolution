"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Mail, Phone, MapPin } from "lucide-react"
import Link from "next/link"
import type { Dentist } from "@/lib/types"

interface DentistListProps {
  dentists: Dentist[]
  onSelectDentist?: (dentist: Dentist) => void
}

export function DentistList({ dentists, onSelectDentist }: DentistListProps) {
  if (dentists.length === 0) {
    return (
      <Card>
        <CardContent className="pt-8 text-center">
          <p className="text-slate-500">Nenhum dentista cadastrado</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {dentists.map((dentist) => (
        <Card key={dentist.id} className="hover:shadow-md transition-shadow">
          <CardHeader>
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1">
                <CardTitle className="text-lg">{dentist.dentistName}</CardTitle>
                <p className="text-sm text-slate-600 mt-1">{dentist.clinicName}</p>
              </div>
              <Badge variant={dentist.status === "active" ? "default" : "secondary"}>
                {dentist.status === "active" ? "Ativo" : "Inativo"}
              </Badge>
            </div>
          </CardHeader>

          <CardContent className="space-y-3">
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-slate-600">
                <MapPin className="h-4 w-4" />
                <span>
                  {dentist.city}, {dentist.stateUf}
                </span>
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <Phone className="h-4 w-4" />
                <a href={`tel:${dentist.phone}`} className="text-blue-600 hover:underline">
                  {dentist.phone}
                </a>
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <Mail className="h-4 w-4" />
                <a href={`mailto:${dentist.email}`} className="text-blue-600 hover:underline">
                  {dentist.email}
                </a>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <Link href={`/dashboard/dentistas/${dentist.id}`} className="flex-1">
                <Button variant="outline" size="sm" className="w-full bg-transparent">
                  Ver Detalhes
                </Button>
              </Link>
              {onSelectDentist && (
                <Button size="sm" onClick={() => onSelectDentist(dentist)} className="flex-1">
                  Editar
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
