"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import type { Dentist } from "@/lib/types"
import { updateDentist } from "@/lib/data-store"

const BRAZILIAN_STATES = [
  "AC",
  "AL",
  "AP",
  "AM",
  "BA",
  "CE",
  "DF",
  "ES",
  "GO",
  "MA",
  "MT",
  "MS",
  "MG",
  "PA",
  "PB",
  "PR",
  "PE",
  "PI",
  "RJ",
  "RN",
  "RS",
  "RO",
  "RR",
  "SC",
  "SP",
  "SE",
  "TO",
]

const PARTNER_STATUS = [
  { value: "active", label: "Ativo" },
  { value: "inactive", label: "Inativo" },
]

interface DentistEditFormProps {
  dentist: Dentist
  onClose?: () => void
  onSuccess?: (dentist: Dentist) => void
}

export function DentistEditForm({ dentist, onClose, onSuccess }: DentistEditFormProps) {
  const { toast } = useToast()
  const [formData, setFormData] = useState<Dentist>(dentist)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isLoading, setIsLoading] = useState(false)

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!formData.dentistName.trim()) {
      newErrors.dentistName = "Nome do dentista é obrigatório"
    }

    if (!formData.clinicName.trim()) {
      newErrors.clinicName = "Nome da clínica é obrigatório"
    }

    if (!formData.city.trim()) {
      newErrors.city = "Cidade é obrigatória"
    }

    if (!formData.stateUf) {
      newErrors.stateUf = "Estado é obrigatório"
    }

    if (!formData.phone.trim()) {
      newErrors.phone = "Telefone é obrigatório"
    } else if (!/^$$\d{2}$$\s\d{5}-\d{4}$/.test(formData.phone)) {
      newErrors.phone = "Telefone deve estar no formato (XX) 9XXXX-XXXX"
    }

    if (!formData.email.trim()) {
      newErrors.email = "E-mail é obrigatório"
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "E-mail inválido"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[field]
        return newErrors
      })
    }
  }

  const formatPhoneInput = (value: string) => {
    const digits = value.replace(/\D/g, "")
    if (digits.length <= 2) return `(${digits}`
    if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7, 11)}`
  }

  const handlePhoneChange = (value: string) => {
    handleInputChange("phone", formatPhoneInput(value))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Erro",
        description: "Por favor, corrija os erros no formulário",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const updatedDentist = updateDentist(dentist.id, formData)

      if (updatedDentist) {
        toast({
          title: "Sucesso",
          description: "Cadastro atualizado com sucesso",
        })

        if (onSuccess) {
          onSuccess(updatedDentist)
        }

        if (onClose) {
          onClose()
        }
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao atualizar cadastro",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const isFormValid =
    formData.dentistName.trim() &&
    formData.clinicName.trim() &&
    formData.city.trim() &&
    formData.stateUf &&
    formData.phone &&
    /^$$\d{2}$$\s\d{5}-\d{4}$/.test(formData.phone) &&
    formData.email.trim() &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Editar Cadastro</CardTitle>
        <CardDescription>Atualize as informações do dentista/clínica</CardDescription>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Dentist and Clinic Names */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="dentistName">Nome do Dentista *</Label>
              <Input
                id="dentistName"
                value={formData.dentistName}
                onChange={(e) => handleInputChange("dentistName", e.target.value)}
                placeholder="Dr. João Silva"
                className={errors.dentistName ? "border-red-500" : ""}
              />
              {errors.dentistName && <p className="text-xs text-red-500">{errors.dentistName}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="clinicName">Nome da Clínica *</Label>
              <Input
                id="clinicName"
                value={formData.clinicName}
                onChange={(e) => handleInputChange("clinicName", e.target.value)}
                placeholder="Clínica Dental Silva"
                className={errors.clinicName ? "border-red-500" : ""}
              />
              {errors.clinicName && <p className="text-xs text-red-500">{errors.clinicName}</p>}
            </div>
          </div>

          {/* Location Section */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Localização da Clínica</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">Cidade *</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => handleInputChange("city", e.target.value)}
                  placeholder="São Paulo"
                  className={errors.city ? "border-red-500" : ""}
                />
                {errors.city && <p className="text-xs text-red-500">{errors.city}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="stateUf">Estado/UF *</Label>
                <Select value={formData.stateUf} onValueChange={(value) => handleInputChange("stateUf", value)}>
                  <SelectTrigger className={errors.stateUf ? "border-red-500" : ""}>
                    <SelectValue placeholder="Selecionar" />
                  </SelectTrigger>
                  <SelectContent>
                    {BRAZILIAN_STATES.map((state) => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.stateUf && <p className="text-xs text-red-500">{errors.stateUf}</p>}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="neighborhood">Bairro (Opcional)</Label>
              <Input
                id="neighborhood"
                value={formData.neighborhood || ""}
                onChange={(e) => handleInputChange("neighborhood", e.target.value)}
                placeholder="Centro"
              />
            </div>
          </div>

          {/* Contact Section */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Contato</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Telefone *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  placeholder="(11) 99999-9999"
                  className={errors.phone ? "border-red-500" : ""}
                />
                {errors.phone && <p className="text-xs text-red-500">{errors.phone}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">E-mail *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="contato@clinica.com"
                  className={errors.email ? "border-red-500" : ""}
                />
                {errors.email && <p className="text-xs text-red-500">{errors.email}</p>}
              </div>
            </div>
          </div>

          {/* Status */}
          <div className="space-y-2">
            <Label htmlFor="status">Status do Parceiro</Label>
            <Select
              value={formData.status}
              onValueChange={(value) => handleInputChange("status", value as "active" | "inactive")}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PARTNER_STATUS.map((status) => (
                  <SelectItem key={status.value} value={status.value}>
                    {status.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Form Actions */}
          <div className="flex gap-3 pt-4">
            <Button type="submit" disabled={!isFormValid || isLoading} className="flex-1">
              {isLoading ? "Salvando..." : "Salvar Alterações"}
            </Button>
            {onClose && (
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
                className="flex-1 bg-transparent"
              >
                Cancelar
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
