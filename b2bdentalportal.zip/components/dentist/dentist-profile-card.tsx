"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Mail, Phone, MapPin, Calendar, Edit2 } from "lucide-react"
import type { Dentist } from "@/lib/types"
import { formatDistanceToNow } from "date-fns"

interface DentistProfileCardProps {
  dentist: Dentist
  onEdit?: () => void
}

export function DentistProfileCard({ dentist, onEdit }: DentistProfileCardProps) {
  const isActive = dentist.status === "active"

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-2xl">{dentist.dentistName}</CardTitle>
            <CardDescription className="text-base mt-1">{dentist.clinicName}</CardDescription>
          </div>
          <Badge variant={isActive ? "default" : "secondary"} className="ml-2">
            {isActive ? "Ativo" : "Inativo"}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Contact Information */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-600">Informações de Contato</h3>
          <div className="space-y-2">
            <div className="flex items-center gap-3 text-sm">
              <Mail className="h-4 w-4 text-slate-400" />
              <a href={`mailto:${dentist.email}`} className="text-blue-600 hover:underline">
                {dentist.email}
              </a>
            </div>
            <div className="flex items-center gap-3 text-sm">
              <Phone className="h-4 w-4 text-slate-400" />
              <a href={`tel:${dentist.phone}`} className="text-blue-600 hover:underline">
                {dentist.phone}
              </a>
            </div>
          </div>
        </div>

        {/* Location Information */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-slate-600">Localização</h3>
          <div className="flex items-start gap-3">
            <MapPin className="h-4 w-4 text-slate-400 mt-0.5 flex-shrink-0" />
            <div className="text-sm space-y-1">
              <div>
                <span className="font-medium">
                  {dentist.city}, {dentist.stateUf}
                </span>
              </div>
              {dentist.neighborhood && <div className="text-slate-600">{dentist.neighborhood}</div>}
            </div>
          </div>
        </div>

        {/* Metadata */}
        <div className="pt-4 border-t border-slate-200">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Calendar className="h-3 w-3" />
            <span>Última atualização: {formatDistanceToNow(new Date(dentist.updatedAt), { addSuffix: true })}</span>
          </div>
        </div>

        {/* Action Button */}
        {onEdit && (
          <Button onClick={onEdit} variant="outline" className="w-full gap-2 bg-transparent">
            <Edit2 className="h-4 w-4" />
            Editar Informações
          </Button>
        )}
      </CardContent>
    </Card>
  )
}
