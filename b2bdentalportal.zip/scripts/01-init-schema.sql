-- Create tables for the dental case management system

-- Users table (for authentication)
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'dentist', -- 'dentist' or 'admin'
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Dentists table
CREATE TABLE IF NOT EXISTS dentists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  dentist_name TEXT NOT NULL,
  clinic_name TEXT NOT NULL,
  city TEXT NOT NULL,
  state_uf TEXT NOT NULL,
  neighborhood TEXT,
  phone TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  status TEXT DEFAULT 'active', -- 'active' or 'inactive'
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cases table
CREATE TABLE IF NOT EXISTS cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_number TEXT UNIQUE NOT NULL,
  patient_name TEXT NOT NULL,
  dentist_id UUID REFERENCES dentists(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'received',
  priority TEXT DEFAULT 'medium',
  due_date TIMESTAMP,
  planning_url TEXT,
  planning_version INTEGER,
  has_unread_messages BOOLEAN DEFAULT FALSE,
  awaiting_dentist BOOLEAN DEFAULT FALSE,
  awaiting_lab BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Case files table
CREATE TABLE IF NOT EXISTS case_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size INTEGER,
  file_url TEXT,
  category TEXT DEFAULT 'other', -- 'stl', 'photo', 'pdf', 'radiograph', 'other'
  uploaded_by TEXT,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Case timeline events
CREATE TABLE IF NOT EXISTS timeline_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL, -- 'status_change', 'file_upload', 'message', 'approval', 'note'
  title TEXT NOT NULL,
  description TEXT,
  user_name TEXT,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  user_name TEXT NOT NULL,
  user_role TEXT NOT NULL, -- 'dentist' or 'admin'
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Clinical prescriptions table
CREATE TABLE IF NOT EXISTS clinical_prescriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
  arches TEXT, -- 'both', 'upper', 'lower'
  treatment_type TEXT, -- 'anterior', 'posterior', 'both'
  overbite TEXT, -- 'maintain', 'improve'
  midline TEXT,
  crossbite TEXT,
  distalization TEXT, -- 'yes', 'no'
  elastics TEXT, -- 'yes', 'no'
  expansion TEXT, -- 'yes', 'no'
  molar_relationship_left TEXT,
  molar_relationship_right TEXT,
  canine_relationship_left TEXT,
  canine_relationship_right TEXT,
  ipr_anterior BOOLEAN,
  ipr_left BOOLEAN,
  ipr_right BOOLEAN,
  ipr_none BOOLEAN,
  restricted_teeth INTEGER[],
  extracted_teeth INTEGER[],
  clinical_notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Refinements table
CREATE TABLE IF NOT EXISTS refinements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
  requested_by TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT DEFAULT 'requested', -- 'requested', 'planning', 'awaiting_approval', 'approved', 'completed'
  planning_url TEXT,
  planning_version INTEGER,
  approved_at TIMESTAMP,
  completed_at TIMESTAMP,
  requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Refinement files
CREATE TABLE IF NOT EXISTS refinement_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  refinement_id UUID REFERENCES refinements(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size INTEGER,
  file_url TEXT,
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_cases_dentist_id ON cases(dentist_id);
CREATE INDEX idx_cases_status ON cases(status);
CREATE INDEX idx_cases_created_at ON cases(created_at DESC);
CREATE INDEX idx_case_files_case_id ON case_files(case_id);
CREATE INDEX idx_messages_case_id ON messages(case_id);
CREATE INDEX idx_timeline_case_id ON timeline_events(case_id);
CREATE INDEX idx_dentists_email ON dentists(email);
CREATE INDEX idx_users_email ON users(email);
