"use server"

import { signIn, signUp, signOut } from "@/lib/auth"
import { redirect } from "next/navigation"

export async function loginAction(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  if (!email || !password) {
    return { error: "Email e senha são obrigatórios" }
  }

  const user = await signIn(email, password)

  if (!user) {
    return { error: "Email ou senha inválidos" }
  }

  redirect(user.role === "admin" ? "/admin" : "/dashboard")
}

export async function registerAction(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const name = formData.get("name") as string
  const clinicName = formData.get("clinicName") as string
  const cro = formData.get("cro") as string

  if (!email || !password || !name) {
    return { error: "Preencha todos os campos obrigatórios" }
  }

  if (password.length < 6) {
    return { error: "A senha deve ter pelo menos 6 caracteres" }
  }

  try {
    await signUp(email, password, name, clinicName, cro)
    redirect("/dashboard")
  } catch (error) {
    return { error: "Erro ao criar conta. Tente novamente." }
  }
}

export async function logoutAction() {
  await signOut()
  redirect("/login")
}
