import { requireAuth } from "@/lib/auth"
import { getAllCases } from "@/lib/data-store"
import { AdminHeader } from "@/components/admin/admin-header"
import { AdminDashboard } from "@/components/admin/admin-dashboard"

export default async function AdminPage() {
  const user = await requireAuth(["admin"])
  const allCases = await getAllCases()

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/30 to-blue-50/30">
      <AdminHeader user={user} />

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Painel Administrativo</h1>
          <p className="text-slate-600">Gerencie todos os casos e monitore o fluxo de trabalho</p>
        </div>

        <AdminDashboard cases={allCases} />
      </main>
    </div>
  )
}
