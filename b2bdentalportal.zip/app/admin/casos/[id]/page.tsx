import { requireAuth } from "@/lib/auth"
import { getCaseById } from "@/lib/data-store"
import { notFound } from "next/navigation"
import { CaseHeader } from "@/components/cases/case-header"
import { CaseTimeline } from "@/components/cases/case-timeline"
import { CaseFiles } from "@/components/cases/case-files"
import { CaseMessages } from "@/components/cases/case-messages"
import { CaseStatusPipeline } from "@/components/cases/case-status-pipeline"
import { AdminHeader } from "@/components/admin/admin-header"
import { PlanningUrlManager } from "@/components/admin/planning-url-manager"
import { RefinementsList } from "@/components/cases/refinements-list"
import { RefinementManager } from "@/components/admin/refinement-manager"
import { ClinicalPrescriptionViewer } from "@/components/cases/clinical-prescription-viewer"

interface AdminCaseDetailPageProps {
  params: Promise<{ id: string }>
}

export default async function AdminCaseDetailPage({ params }: AdminCaseDetailPageProps) {
  const { id } = await params
  const user = await requireAuth(["admin"])
  const caseData = getCaseById(id)

  if (!caseData) {
    notFound()
  }

  const activeRefinement = caseData.refinements?.find(
    (r) => r.status === "requested" || r.status === "planning" || r.status === "awaiting_approval",
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/30 to-blue-50/30">
      <AdminHeader user={user} />

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <CaseHeader caseData={caseData} userRole={user.role} />

        <div className="mt-8">
          <CaseStatusPipeline status={caseData.status} caseId={id} isAdmin={true} userName={user.name} />
        </div>

        {caseData.clinicalPrescription && (
          <div className="mt-6">
            <ClinicalPrescriptionViewer
              prescription={caseData.clinicalPrescription}
              patientName={caseData.patientName}
              caseNumber={caseData.caseNumber}
            />
          </div>
        )}

        {(caseData.status === "planning" || caseData.status === "awaiting_approval") && (
          <div className="mt-6">
            <PlanningUrlManager
              caseId={caseData.id}
              currentUrl={caseData.planningUrl}
              version={caseData.planningVersion}
              onSave={(url) => {
                console.log("[v0] Admin saved planning URL:", url)
              }}
            />
          </div>
        )}

        {caseData.status === "refinement" && activeRefinement && (
          <div className="mt-6">
            <RefinementManager caseId={caseData.id} refinement={activeRefinement} />
          </div>
        )}

        {caseData.refinements && caseData.refinements.length > 0 && (
          <div className="mt-6">
            <RefinementsList
              caseId={caseData.id}
              refinements={caseData.refinements}
              isAdmin={true}
              userName={user.name}
            />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          <div className="lg:col-span-2 space-y-6">
            <CaseTimeline timeline={caseData.timeline} />
            <CaseFiles files={caseData.files} caseId={caseData.id} refinements={caseData.refinements} />
          </div>

          <div className="lg:col-span-1">
            <CaseMessages messages={caseData.messages} caseId={caseData.id} currentUserId={user.id} />
          </div>
        </div>
      </main>
    </div>
  )
}
