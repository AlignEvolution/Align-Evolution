import { Suspense } from "react"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DentistList } from "@/components/dentist/dentist-list"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"
import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"
import { getAllDentists } from "@/lib/data-store"

export const metadata = {
  title: "Dentistas - CRM Align Evolution",
  description: "Gerenciar dentistas e clínicas",
}

export default async function DentistasPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  const dentists = getAllDentists()

  return (
    <div className="min-h-screen bg-slate-50">
      <DashboardHeader user={session.user} />

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Dentistas / Clínicas</h1>
              <p className="text-slate-600 mt-1">Gerencie os perfis dos dentistas e clínicas parceiras</p>
            </div>
            {session.user.role === "admin" && (
              <Link href="/dashboard/dentistas/novo">
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Novo Dentista
                </Button>
              </Link>
            )}
          </div>

          {/* List */}
          <Suspense fallback={<div>Carregando...</div>}>
            <DentistList dentists={dentists} />
          </Suspense>
        </div>
      </main>
    </div>
  )
}
