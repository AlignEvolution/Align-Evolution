import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { DentistProfileCard } from "@/components/dentist/dentist-profile-card"
import { DentistEditDialog } from "@/components/dentist/dentist-edit-dialog"
import { getDentistById } from "@/lib/data-store"
import type { Dentist } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function DentistDetailPage() {
  const params = useParams()
  const dentistId = params.id as string
  const [dentist, setDentist] = useState<Dentist | null>(null)
  const [isEditOpen, setIsEditOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadDentist = async () => {
      setIsLoading(true)
      const data = getDentistById(dentistId)
      setDentist(data || null)
      setIsLoading(false)
    }

    loadDentist()
  }, [dentistId])

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>
  }

  if (!dentist) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="text-slate-600 mb-4">Dentista não encontrado</p>
          <Link href="/dashboard/dentistas">
            <Button>Voltar para a lista</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-2xl mx-auto px-4">
        <Link
          href="/dashboard/dentistas"
          className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          Voltar para Dentistas
        </Link>

        <DentistProfileCard dentist={dentist} onEdit={() => setIsEditOpen(true)} />

        <DentistEditDialog
          dentist={dentist}
          open={isEditOpen}
          onOpenChange={setIsEditOpen}
          onSuccess={(updatedDentist) => setDentist(updatedDentist)}
        />
      </div>
    </div>
  )
}
