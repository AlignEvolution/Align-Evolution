import { requireAuth } from "@/lib/auth"
import { getCaseById } from "@/lib/data-store"
import { notFound } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { CaseHeader } from "@/components/cases/case-header"
import { CaseTimeline } from "@/components/cases/case-timeline"
import { CaseFiles } from "@/components/cases/case-files"
import { CaseMessages } from "@/components/cases/case-messages"
import { CaseStatusPipeline } from "@/components/cases/case-status-pipeline"
import { PlanningApproval } from "@/components/cases/planning-approval"
import { RequestRefinement } from "@/components/cases/request-refinement"
import { RefinementsList } from "@/components/cases/refinements-list"
import { ClinicalPrescriptionViewer } from "@/components/cases/clinical-prescription-viewer"

interface CaseDetailPageProps {
  params: Promise<{ id: string }>
}

export default async function CaseDetailPage({ params }: CaseDetailPageProps) {
  const { id } = await params
  const user = await requireAuth(["dentist", "admin"])
  const caseData = await getCaseById(id)

  if (!caseData) {
    notFound()
  }

  // Check if dentist owns the case
  if (user.role === "dentist" && caseData.dentistId !== user.id) {
    notFound()
  }

  console.log("[v0] Case ID:", caseData.id)
  console.log("[v0] Case Status:", caseData.status)
  console.log("[v0] Planning URL:", caseData.planningUrl)
  console.log("[v0] User Role:", user.role)
  console.log("[v0] Should show planning?", !!caseData.planningUrl && user.role === "dentist")
  console.log("[v0] Has Clinical Prescription?", !!caseData.clinicalPrescription)

  const canRequestRefinement = user.role === "dentist" && caseData.status === "delivered"

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/30">
      <DashboardHeader user={user} />

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <CaseHeader caseData={caseData} userRole={user.role} />

        <div className="mt-8">
          <CaseStatusPipeline status={caseData.status} />
        </div>

        {caseData.clinicalPrescription && (
          <div className="mt-6">
            <ClinicalPrescriptionViewer
              prescription={caseData.clinicalPrescription}
              patientName={caseData.patientName}
              caseNumber={caseData.caseNumber}
            />
          </div>
        )}

        {caseData.planningUrl && user.role === "dentist" && (
          <div className="mt-6">
            <PlanningApproval
              caseId={caseData.id}
              planningUrl={caseData.planningUrl}
              version={caseData.planningVersion}
              status={caseData.status}
              onApprove={(notes) => {
                console.log("[v0] Dentist approved planning with notes:", notes)
              }}
              onRequestChanges={(reason) => {
                console.log("[v0] Dentist requested changes:", reason)
              }}
            />
          </div>
        )}

        {canRequestRefinement && (
          <div className="mt-6">
            <RequestRefinement caseId={caseData.id} dentistName={user.name} />
          </div>
        )}

        {caseData.refinements && caseData.refinements.length > 0 && (
          <div className="mt-6">
            <RefinementsList
              caseId={caseData.id}
              refinements={caseData.refinements}
              isAdmin={false}
              userName={user.name}
            />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
          <div className="lg:col-span-2 space-y-6">
            <CaseTimeline timeline={caseData.timeline} />
            <CaseFiles files={caseData.files} caseId={caseData.id} refinements={caseData.refinements} />
          </div>

          <div className="lg:col-span-1">
            <CaseMessages messages={caseData.messages} caseId={caseData.id} currentUserId={user.id} />
          </div>
        </div>
      </main>
    </div>
  )
}
