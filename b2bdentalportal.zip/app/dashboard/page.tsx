import { requireAuth } from "@/lib/auth"
import { getCasesByDentist } from "@/lib/data-store"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardStats } from "@/components/dashboard/dashboard-stats"
import { CasesList } from "@/components/dashboard/cases-list"

export default async function DashboardPage() {
  const user = await requireAuth(["dentist"])
  const cases = getCasesByDentist(user.id)

  // Calculate statistics
  const stats = {
    total: cases.length,
    awaitingApproval: cases.filter((c) => c.status === "awaiting_approval").length,
    inProduction: cases.filter((c) => c.status === "in_production").length,
    pending: cases.filter((c) => c.awaitingDentist).length,
    unreadMessages: cases.filter((c) => c.hasUnreadMessages).length,
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/30">
      <DashboardHeader user={user} />

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Meus Casos</h1>
          <p className="text-slate-600">Gerencie e acompanhe todos os seus casos ortodônticos</p>
        </div>

        <DashboardStats stats={stats} />
        <CasesList cases={cases} />
      </main>
    </div>
  )
}
